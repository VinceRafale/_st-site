# WordPress MySQL database migration
#
# Generated: Wednesday 26. February 2014 23:05 UTC
# Hostname: localhost
# Database: `sarahtomlinson`
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `ws__wsd_plugin_alerts`
#

DROP TABLE IF EXISTS `ws__wsd_plugin_alerts`;


#
# Table structure of table `ws__wsd_plugin_alerts`
#

CREATE TABLE `ws__wsd_plugin_alerts` (
  `alertId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `alertType` tinyint(4) NOT NULL DEFAULT '0',
  `alertSeverity` int(11) NOT NULL DEFAULT '0',
  `alertActionName` varchar(255) NOT NULL,
  `alertTitle` varchar(255) NOT NULL,
  `alertDescription` text NOT NULL,
  `alertSolution` text NOT NULL,
  `alertDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `alertFirstSeen` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`alertId`),
  UNIQUE KEY `alertId_UNIQUE` (`alertId`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;


#
# Data contents of table `ws__wsd_plugin_alerts`
#
INSERT INTO `ws__wsd_plugin_alerts` ( `alertId`, `alertType`, `alertSeverity`, `alertActionName`, `alertTitle`, `alertDescription`, `alertSolution`, `alertDate`, `alertFirstSeen`) VALUES
(1, 0, 0, 'fix_wp_version_hidden', 'WordPress version is only displayed to administrator users', '<p>Displaying your WordPress version on frontend and in the backend\'s footer to all visitors\r\n                        and users of your website is a security risk because if a hacker knows which version of WordPress a website is running, it can make it easier for him to target a known WordPress security issue.</p>', '', '2014-02-26 15:05:02', '2014-02-10 00:32:07'),
(2, 0, 0, 'fix_wp_generators_frontend', 'WordPress meta tags are only displayed on frontend to administrator users', '<p>By default, WordPress creates a few meta tags, among which is the currently installed version, that give a hacker the knowledge about your WordPress installation.\r\n                At the moment, all WordPress\'s defaults meta tags are hidden for all users but administrators.</p>', '', '2014-02-26 15:05:02', '2014-02-10 00:32:07'),
(3, 0, 0, 'fix_wp_rsd_frontend', 'WordPress Really Simple Discovery tag is only displayed on frontend to administrator users.', '<p>By default, WordPress creates the <strong>rsd meta tag</strong> to allow bloggers to consume services like Flickr using the <a href="http://en.wikipedia.org/wiki/XML-RPC" target="_blank">XML-RPC</a> protocol.\r\n                            If you don\'t use such services it is recommended to hide this meta tag.</p>', '', '2014-02-26 15:05:02', '2014-02-10 00:32:07'),
(4, 0, 0, 'fix_wp_wlw_frontend', 'WordPress Windows Live Writer tag is only displayed on frontend for administrator users', '<p>By default, WordPress creates the wlw meta tag to allow bloggers to publish their articles using the <strong>"Windows Live Writer"</strong> application.\r\n                        It is recommended to hide this meta tag from all visitors. If the option <strong>"Remove Windows Live Writer meta tags from front-end"</strong> is checked on the plugin\'s settings page, this meta tag\r\n                        will still be available for administrator users to use the <strong>"Windows Live Writer"</strong> application to publish their blog posts.</p>', '', '2014-02-26 15:05:02', '2014-02-10 00:32:07'),
(5, 0, 0, 'fix_wp_error_reporting', 'Error reporting, PHP and database, is enabled only for administrator users', '<p>By default, WordPress hides database errors, but there are times when a plugin might enable them thus it is very important to have this type of errors turned off\r\n                        so if there is an error during a connection to the database the user will not get access to the error message generated during that request.</p>\r\n                        <p>As regarding the PHP errors, with the <strong>display_error</strong> PHP configuration directive enabled, untrusted sources can see detailed web application environment\r\n                        error messages which include sensitive information that can be used to craft further attacks.</p>\r\n                        <p>Attackers will do anything to collect information in order to design their attack in a more sophisticated way to eventually hack your website or web application, and causing\r\n                        errors to display is a common starting point. Website errors can always occur, but they should be suppressed from being displayed back to the public.</p>\r\n                        <p>Therefore we highly recommend you to have the <strong>"Disable error reporting (php + db) for all but administrators"</strong> option checked on the plugin\'s settings page to ensure PHP and\r\n                        database errors will be hidden from all users. For more information, please check the following <a href="http://www.acunetix.com/blog/web-security-zone/articles/php-security-directive-your-website-is-showing-php-errors/" target="_blank">article</a>.</p>', '', '2014-02-26 15:05:02', '2014-02-10 00:32:07'),
(6, 0, 0, 'fix_wp_core_update_notif', 'Core update notifications are only displayed to administrator users.', '<p>These notifications are displayed at the top of the screen by the WordPress platform whenever the website was updated or needs an update.</p>\r\n                <p>Currently, these notifications are only displayed to administrator users.</p>', '', '2014-02-26 15:05:02', '2014-02-10 00:32:07'),
(7, 0, 0, 'fix_wp_plugins_update_notif', 'Plugins update notifications are only displayed to administrator users', '<p>Currently, these notifications are only displayed to administrator users.</p>', '', '2014-02-26 15:05:02', '2014-02-10 00:32:07'),
(8, 0, 0, 'fix_wp_themes_update_notif', 'Themes update notifications are only displayed to administrator users', '<p>Currently, these notifications are only displayed to administrator users.</p>', '', '2014-02-26 15:05:02', '2014-02-10 00:32:07'),
(9, 0, 0, 'fix_wp_login_errors', 'WordPress login errors are not displayed.', '<p>Currently, these errors are hidden to all users.</p>', '', '2014-02-26 15:05:02', '2014-02-10 00:32:07'),
(10, 0, 0, 'fix_wp_admin_notices', 'WordPress admin notifications are only displayed to administrator users.', '<p>These notifications are displayed at the top of the screen by the WordPress platform whenever the blog administrator\r\n                       needs to be informed about an event that has occurred inside WordPress, it could be about an available update for the\r\n                       WordPress platform, a plugin or a theme that was updated or needs an update or to be configured, etc.</p>\r\n                <p>Currently, these notifications are displayed only to administrator users.</p>', '', '2014-02-26 15:05:02', '2014-02-10 00:32:07'),
(11, 0, 0, 'fix_wp_dir_listing', 'Directory listing check is enabled.', '<p>A directory listing provides an attacker with the complete index of all the resources located inside of the directory.\r\n                    The specific risks and consequences vary depending on which files are listed and accessible.\r\n                    Therefore, it is important to protect your directories by having an empty index.php or index.htm file inside them.</p>', '', '2014-02-26 15:05:02', '2014-02-10 00:32:07'),
(12, 0, 0, 'fix_remove_wp_version_links', 'WordPress version displayed in links only for administrator users.', '<p>By default, WordPress will display the current version in links to javascript scripts or stylesheets.\r\n                    Therefore, if anyone has access to this information it might be a security risk because if a hacker knows which version of WordPress a website is running,\r\n                    it can make it easier for him to target a known WordPress security issue.</p>', '', '2014-02-26 15:05:02', '2014-02-10 00:32:07'),
(13, 0, 0, 'fix_empty_root_readme_file', 'The content of the readme.html file from the root directory has been deleted.', '<p>A default WordPress installation contains a readme.html file. This file is a simple html file that does not contain executable content that can be exploited by hackers or malicious users.\r\n                        Still, this file can provide hackers the version of your WordPress installation, therefore it is important to either delete this file or make it inaccessible for your visitors.</p>', '', '2014-02-10 00:33:03', '2014-02-10 00:32:07'),
(14, 0, 0, 'check_table_prefix', 'The default WordPress database prefix is not used', '<p>The majority of reported WordPress database security attacks were performed by exploiting SQL Injection vulnerabilities.\r\n                        By renaming the WordPress database table prefixes you are securing your WordPress blog and website from zero day SQL injections attacks.</p>\r\n                    <p>Therefore by renaming the WordPress database table prefixes, you are automatically enforcing your WordPress database security against such dangerous attacks because the attacker would not be able to guess the table names.</p>', '', '2014-02-26 15:05:02', '2014-02-10 00:32:07'),
(15, 0, 0, 'check_wp_current_version', 'You have the latest version of WordPress installed', '<p>The latest WordPress version is usually more stable and secure, and is only released to include new features or fix technical and WordPress security bugs;\r\n                            making it an important part of your website administration to keep up to date since some fixes might resolve security issues.<p>\r\n                        <p>Running an older WordPress version could put your blog security at risk, allowing a hacker to exploit known vulnerabilities for your specific version and take full control over your web server.</p>', '', '2014-02-26 15:05:02', '2014-02-10 00:32:07'),
(16, 0, 0, 'check_index_wp_content', 'The <strong>"index.php"</strong> file was found in the <strong>"/wp-content"</strong> directory', '<p>A directory listing provides an attacker with the complete index of all the resources located inside of the directory. The specific risks and consequences vary depending on which files are listed and accessible.</p>\r\n                    <p>Therefore, it is important to protect your directories by having an empty index.php or index.htm file inside them.</p>', '', '2014-02-26 15:05:02', '2014-02-10 00:32:07'),
(17, 0, 0, 'check_index_wp_plugins', 'The <strong>"index.php"</strong> file was found in the <strong>"/wp-content/plugins"</strong> directory', '<p>A directory listing provides an attacker with the complete index of all the resources located inside of the directory. The specific risks and consequences vary depending on which files are listed and accessible.</p>\r\n                    <p>Therefore, it is important to protect your directories by having an empty index.php or index.htm file inside them.</p>', '', '2014-02-26 15:05:02', '2014-02-10 00:32:07'),
(18, 0, 0, 'check_index_wp_themes', 'The <strong>"index.php"</strong> file was found in the <strong>"/wp-content/themes"</strong> directory', '<p>A directory listing provides an attacker with the complete index of all the resources located inside of the directory. The specific risks and consequences vary depending on which files are listed and accessible.</p>\r\n                    <p>Therefore, it is important to protect your directories by having an empty index.php or index.htm file inside them.</p>', '', '2014-02-26 15:05:02', '2014-02-10 00:32:07'),
(19, 0, 2, 'check_htaccess_wp_admin', 'The <strong>".htaccess"</strong> file was not found in the <strong>"wp-admin"</strong> directory', '<p>An .htaccess file is a configuration file which provides the ability to specify configuration settings for a specific directory in a website.\r\n                    The .htaccess file can include one or more configuration settings which apply only for the directory in which the .htaccess file has been placed.\r\n                    So while web servers have their own main configuration settings file, the .htaccess file can be used to override their main configuration settings.</p>', '<p>Please refer to this <a href="http://www.acunetix.com/blog/web-security-zone/articles/what-is-an-htaccess-file/" target="_blank">article</a> for more information on how to create an .htaccess file.</p>', '2014-02-26 15:05:02', '2014-02-10 00:32:07'),
(20, 0, 0, 'check_readme_wp_root', 'The <strong>readme.html</strong> file is either empty or not accessible.', '<p>A default WordPress installation contains a readme.html file.\r\n                                This file is a simple html file that does not contain executable content that can be exploited by hackers or malicious users.\r\n                                Still, this file can provide hackers the version of your WordPress installation, therefore it is important to either delete this file or make it inaccessible for your visitors.</p>', '', '2014-02-26 15:05:02', '2014-02-10 00:32:07'),
(21, 0, 0, 'check_username_admin ', 'User <strong>"admin"</strong> (with administrative rights) was not found', '<p>One well known and dangerous WordPress security vulnerability is User Enumeration, in which a\r\n                            malicious user is able to enumerate a valid WordPress user account to launch a brute force attack against it.\r\n                            In order to help deter this type of attack, it is important not to have the default <a href="http://www.acunetix.com/blog/web-security-zone/articles/default-wordpress-administrator-account/" target="_blank">WordPress administrator</a>\r\n                            username enabled on your blog.</p>', '', '2014-02-26 15:04:05', '2014-02-10 00:32:07'),
(22, 0, 2, 'check_wp_admin_install', 'The <strong>"install.php"</strong> file was found in the <strong>"/wp-admin"</strong> directory', '<p>The install.php file is needed to install WordPress and it is good practice to restrict access to it or delete it afterwards.</p>', '<p>Change file permissions 000 <strong>chmod(000)</strong> or delete it from the <strong>/wp-admin</strong> directory</p>', '2014-02-26 15:04:05', '2014-02-10 00:32:07'),
(23, 0, 2, 'check_wp_admin_upgrade', 'The <strong>"upgrade.php"</strong> file was found in the <strong>"/wp-admin"</strong> directory', '<p>The upgrade.php file is needed to upgrade WordPress and it is good practice to restrict access to it or delete it afterwards.</p>', '<p>Change file permissions 000 <strong>chmod(000)</strong> or delete it from the <strong>/wp-admin</strong> directory</p>', '2014-02-26 15:04:05', '2014-02-10 00:32:07'),
(24, 0, 0, 'check_index_wp_uploads', 'The <strong>"index.php"</strong> file was found in the <strong>"/wp-content/uploads"</strong> directory', '<p>A directory listing provides an attacker with the complete index of all the resources located inside of the directory. The specific risks and consequences vary depending on which files are listed and accessible.</p>\r\n                    <p>Therefore, it is important to protect your directories by having an empty index.php or index.htm file inside them.</p>', '', '2014-02-26 15:05:02', '2014-02-10 00:32:34'),
(25, 0, 0, 'fix_wp_index_content', '<strong>"/wp-content"</strong> directory is secure from directory listing.', '<p>A directory listing provides an attacker with the complete index of all the resources located inside of the directory.\r\n                    The specific risks and consequences vary depending on which files are listed and accessible.\r\n                    Therefore, it is important to protect your directories by having an empty index.php or index.htm file inside them.</p>', '', '2014-02-26 15:05:02', '2014-02-10 00:33:03'),
(26, 0, 0, 'fix_wp_index_plugins', '<strong>"/wp-content/plugins"</strong> directory is not secure from directory listing.', '<p>A directory listing provides an attacker with the complete index of all the resources located inside of the directory.\r\n                            The specific risks and consequences vary depending on which files are listed and accessible.\r\n                            Therefore, it is important to protect your directories by having an empty index.php or index.htm file inside them.</p>', '', '2014-02-26 15:05:02', '2014-02-10 00:33:03'),
(27, 0, 0, 'fix_wp_index_themes', '<strong>"/wp-content/themes"</strong> directory is not secure from directory listing.', '<p>A directory listing provides an attacker with the complete index of all the resources located inside of the directory.\r\n                            The specific risks and consequences vary depending on which files are listed and accessible.\r\n                            Therefore, it is important to protect your directories by having an empty index.php or index.htm file inside them.</p>', '', '2014-02-26 15:05:02', '2014-02-10 00:33:03'),
(28, 0, 0, 'fix_wp_index_uploads', '<strong>"/wp-content/uploads"</strong> directory is not secure from directory listing.', '<p>A directory listing provides an attacker with the complete index of all the resources located inside of the directory.\r\n                            The specific risks and consequences vary depending on which files are listed and accessible.\r\n                            Therefore, it is important to protect your directories by having an empty index.php or index.htm file inside them.</p>', '', '2014-02-26 15:05:02', '2014-02-10 00:33:03') ;

#
# End of data contents of table `ws__wsd_plugin_alerts`
# --------------------------------------------------------



#
# Delete any existing table `ws__wsd_plugin_live_traffic`
#

DROP TABLE IF EXISTS `ws__wsd_plugin_live_traffic`;


#
# Table structure of table `ws__wsd_plugin_live_traffic`
#

CREATE TABLE `ws__wsd_plugin_live_traffic` (
  `entryId` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `entryTime` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `entryIp` text,
  `entryReferrer` text,
  `entryUA` text,
  `entryRequestedUrl` text,
  `entryCountry` varchar(125) NOT NULL,
  `entryCity` varchar(125) NOT NULL,
  `blogId` int(10) NOT NULL DEFAULT '1',
  PRIMARY KEY (`entryId`)
) ENGINE=InnoDB AUTO_INCREMENT=180 DEFAULT CHARSET=utf8;


#
# Data contents of table `ws__wsd_plugin_live_traffic`
#
INSERT INTO `ws__wsd_plugin_live_traffic` ( `entryId`, `entryTime`, `entryIp`, `entryReferrer`, `entryUA`, `entryRequestedUrl`, `entryCountry`, `entryCity`, `blogId`) VALUES
(1, '2014-02-10 00:34:47', '127.0.0.1', 'http://sarahtomlinson:8888/wp-admin/options-general.php?settings-updated=true', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.102 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(2, '2014-02-10 00:35:31', '127.0.0.1', 'http://sarahtomlinson:8888/wp-admin/options-general.php?settings-updated=true', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.102 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(3, '2014-02-10 00:35:34', '127.0.0.1', 'http://sarahtomlinson:8888/wp-admin/options-general.php?settings-updated=true', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.102 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(4, '2014-02-10 00:36:23', '127.0.0.1', 'http://sarahtomlinson:8888/wp-admin/options-general.php?settings-updated=true', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.102 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(5, '2014-02-10 00:38:05', '127.0.0.1', 'http://sarahtomlinson:8888/wp-admin/options-general.php?settings-updated=true', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.102 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(6, '2014-02-10 00:38:21', '127.0.0.1', 'http://sarahtomlinson:8888/wp-admin/options-general.php?settings-updated=true', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.102 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(7, '2014-02-10 00:38:47', '127.0.0.1', 'http://sarahtomlinson:8888/wp-admin/options-general.php?settings-updated=true', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.102 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(8, '2014-02-10 00:39:31', '127.0.0.1', 'http://sarahtomlinson:8888/wp-admin/options-general.php?settings-updated=true', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.102 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(9, '2014-02-10 00:41:00', '127.0.0.1', 'http://sarahtomlinson:8888/wp-admin/options-general.php?settings-updated=true', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.102 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(10, '2014-02-10 00:41:04', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.102 Safari/537.36', 'http://sarahtomlinson:8888/?m=201402', '', '', 0),
(11, '2014-02-10 00:41:07', '127.0.0.1', 'http://sarahtomlinson:8888/?m=201402', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.102 Safari/537.36', 'http://sarahtomlinson:8888/?cat=1', '', '', 0),
(12, '2014-02-10 00:41:09', '127.0.0.1', 'http://sarahtomlinson:8888/?cat=1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.102 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(13, '2014-02-10 01:57:45', '127.0.0.1', '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.102 Safari/537.36', 'http://sarahtomlinson:8888/wp-login.php?redirect_to=http%3A%2F%2Fwebstart%2F_sandbox%2Fwp-admin%2F&#038;reauth=1', '', '', 0),
(14, '2014-02-10 01:57:53', '127.0.0.1', 'http://sarahtomlinson:8888/wp-login.php?redirect_to=http%3A%2F%2Fwebstart%2F_sandbox%2Fwp-admin%2F&amp;reauth=1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.102 Safari/537.36', 'http://sarahtomlinson:8888/wp-login.php', '', '', 0),
(15, '2014-02-10 02:03:57', '127.0.0.1', 'http://sarahtomlinson:8888/wp-admin/plugins.php?activate=true&amp;plugin_status=all&amp;paged=1&amp;s=', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.102 Safari/537.36', 'http://sarahtomlinson:8888/wp-login.php?redirect_to=http%3A%2F%2Fwebstart%2Fwp-admin%2Ftools.php%3Fpage%3Dwp-migrate-db-pro&#038;reauth=1', '', '', 0),
(16, '2014-02-10 02:04:01', '127.0.0.1', 'http://sarahtomlinson:8888/wp-login.php?redirect_to=http%3A%2F%2Fwebstart%2Fwp-admin%2Ftools.php%3Fpage%3Dwp-migrate-db-pro&amp;reauth=1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.102 Safari/537.36', 'http://sarahtomlinson:8888/wp-login.php', '', '', 0),
(17, '2014-02-10 02:04:02', '127.0.0.1', 'http://sarahtomlinson:8888/wp-login.php?redirect_to=http%3A%2F%2Fwebstart%2Fwp-admin%2Ftools.php%3Fpage%3Dwp-migrate-db-pro&amp;reauth=1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.102 Safari/537.36', 'http://sarahtomlinson:8888/wp-login.php?redirect_to=http%3A%2F%2Fwebstart%2Fwp-admin%2Ftools.php%3Fpage%3Dwp-migrate-db-pro&#038;reauth=1', '', '', 0),
(18, '2014-02-10 02:05:45', '127.0.0.1', 'http://sarahtomlinson:8888/wp-admin/tools.php?page=wp-migrate-db-pro&amp;wpmdb-profile=0', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.102 Safari/537.36', 'http://sarahtomlinson:8888/wp-login.php?interim-login=1', '', '', 0),
(19, '2014-02-10 02:05:51', '127.0.0.1', 'http://sarahtomlinson:8888/wp-login.php?interim-login=1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.102 Safari/537.36', 'http://sarahtomlinson:8888/wp-login.php', '', '', 0),
(20, '2014-02-10 02:18:02', '127.0.0.1', '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9) AppleWebKit/537.71 (KHTML, like Gecko)', 'http://elysian-landscapes/', '', '', 0),
(21, '2014-02-10 02:18:07', '127.0.0.1', '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9) AppleWebKit/537.71 (KHTML, like Gecko)', 'http://elysian-landscapes/', '', '', 0),
(22, '2014-02-11 15:13:58', '127.0.0.1', '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(23, '2014-02-11 15:14:38', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/?p=1', '', '', 0),
(24, '2014-02-11 15:14:45', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/?page_id=2', '', '', 0),
(25, '2014-02-11 15:20:47', '127.0.0.1', '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9) AppleWebKit/537.71 (KHTML, like Gecko)', 'http://sarahtomlinson:8888/', '', '', 0),
(26, '2014-02-11 15:22:07', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/?page_id=2', '', '', 0),
(27, '2014-02-11 15:22:47', '127.0.0.1', 'http://sarahtomlinson:8888/?page_id=2', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/?page_id=2', '', '', 0),
(28, '2014-02-11 15:22:48', '127.0.0.1', 'http://sarahtomlinson:8888/?page_id=2', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/?page_id=2&#038;updated=true', '', '', 0),
(29, '2014-02-11 15:26:22', '127.0.0.1', 'http://sarahtomlinson:8888/?page_id=2', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/?page_id=2&#038;updated=true', '', '', 0),
(30, '2014-02-14 04:04:14', '127.0.0.1', '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(31, '2014-02-14 04:04:20', '127.0.0.1', '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/wp-login.php?redirect_to=http%3A%2F%2Fwebstart%2Fwp-admin%2F&#038;reauth=1', '', '', 0),
(32, '2014-02-14 04:04:29', '127.0.0.1', 'http://sarahtomlinson:8888/wp-login.php?redirect_to=http%3A%2F%2Fwebstart%2Fwp-admin%2F&amp;reauth=1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/wp-login.php', '', '', 0),
(33, '2014-02-14 04:04:33', '127.0.0.1', 'http://sarahtomlinson:8888/wp-login.php', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/wp-login.php', '', '', 0),
(34, '2014-02-14 04:08:30', '127.0.0.1', 'http://sarahtomlinson:8888/installer.php', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/wp-login.php?redirect_to=http%3A%2F%2Fsarahtomlinson%2Fwp-admin%2Foptions-permalink.php&#038;reauth=1', '', '', 0),
(35, '2014-02-14 04:08:38', '127.0.0.1', 'http://sarahtomlinson:8888/wp-login.php?redirect_to=http%3A%2F%2Fsarahtomlinson%2Fwp-admin%2Foptions-permalink.php&amp;reauth=1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/wp-login.php', '', '', 0),
(36, '2014-02-14 04:09:17', '127.0.0.1', 'http://sarahtomlinson:8888/installer.php', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(37, '2014-02-15 03:11:51', '127.0.0.1', '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(38, '2014-02-15 03:17:26', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(39, '2014-02-15 03:17:26', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(40, '2014-02-15 03:27:30', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(41, '2014-02-15 03:27:31', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(42, '2014-02-15 03:36:52', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(43, '2014-02-15 03:39:49', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(44, '2014-02-15 03:39:49', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(45, '2014-02-15 03:40:55', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(46, '2014-02-15 03:43:00', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(47, '2014-02-15 03:43:23', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(48, '2014-02-15 03:43:44', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(49, '2014-02-15 03:43:48', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(50, '2014-02-15 03:43:53', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/page/2/', '', '', 0),
(51, '2014-02-15 03:44:04', '127.0.0.1', 'http://sarahtomlinson:8888/page/2/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/page/2/', '', '', 0),
(52, '2014-02-15 03:44:08', '127.0.0.1', 'http://sarahtomlinson:8888/page/2/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/page/2/', '', '', 0),
(53, '2014-02-15 03:45:03', '127.0.0.1', 'http://sarahtomlinson:8888/page/2/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/page/2/', '', '', 0),
(54, '2014-02-15 03:45:03', '127.0.0.1', 'http://sarahtomlinson:8888/page/2/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/page/2/', '', '', 0),
(55, '2014-02-15 03:45:06', '127.0.0.1', 'http://sarahtomlinson:8888/page/2/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/page/2/', '', '', 0),
(56, '2014-02-15 03:45:11', '127.0.0.1', 'http://sarahtomlinson:8888/page/2/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/page/2/', '', '', 0),
(57, '2014-02-15 03:45:12', '127.0.0.1', 'http://sarahtomlinson:8888/page/2/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/page/2/', '', '', 0),
(58, '2014-02-15 03:45:16', '127.0.0.1', 'http://sarahtomlinson:8888/page/2/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(59, '2014-02-15 03:45:20', '127.0.0.1', 'http://sarahtomlinson:8888/page/2/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(60, '2014-02-15 03:47:34', '127.0.0.1', 'http://sarahtomlinson:8888/page/2/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(61, '2014-02-15 03:49:16', '127.0.0.1', 'http://sarahtomlinson:8888/page/2/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(62, '2014-02-15 03:50:55', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(63, '2014-02-15 03:51:29', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(64, '2014-02-15 03:51:29', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(65, '2014-02-15 03:52:11', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(66, '2014-02-15 03:52:40', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(67, '2014-02-15 03:54:00', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(68, '2014-02-15 03:54:01', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(69, '2014-02-15 04:11:42', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(70, '2014-02-15 04:13:02', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(71, '2014-02-15 04:14:18', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(72, '2014-02-15 04:14:19', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(73, '2014-02-15 04:15:31', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(74, '2014-02-15 04:15:50', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(75, '2014-02-15 04:16:48', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(76, '2014-02-15 04:16:49', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(77, '2014-02-15 04:24:22', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(78, '2014-02-15 04:24:22', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(79, '2014-02-15 04:24:29', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(80, '2014-02-15 04:28:38', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(81, '2014-02-15 04:28:38', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(82, '2014-02-15 04:30:24', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(83, '2014-02-15 04:30:25', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(84, '2014-02-15 04:31:13', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(85, '2014-02-15 04:31:14', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(86, '2014-02-16 21:33:37', '127.0.0.1', '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(87, '2014-02-16 21:35:06', '127.0.0.1', '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(88, '2014-02-16 21:58:19', '127.0.0.1', '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(89, '2014-02-16 21:58:19', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(90, '2014-02-16 22:00:54', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(91, '2014-02-16 22:01:00', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(92, '2014-02-16 22:02:06', '127.0.0.1', '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/wp-login.php?redirect_to=http%3A%2F%2Fsarahtomlinson%2Fwp-admin%2F&#038;reauth=1', '', '', 0),
(93, '2014-02-16 22:02:14', '127.0.0.1', 'http://sarahtomlinson:8888/wp-login.php?redirect_to=http%3A%2F%2Fsarahtomlinson%2Fwp-admin%2F&amp;reauth=1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/wp-login.php', '', '', 0),
(94, '2014-02-16 22:03:39', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(95, '2014-02-16 22:04:09', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(96, '2014-02-16 22:12:04', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(97, '2014-02-16 22:12:04', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(98, '2014-02-16 22:12:28', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(99, '2014-02-16 22:14:40', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(100, '2014-02-16 22:24:17', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0) ;
INSERT INTO `ws__wsd_plugin_live_traffic` ( `entryId`, `entryTime`, `entryIp`, `entryReferrer`, `entryUA`, `entryRequestedUrl`, `entryCountry`, `entryCity`, `blogId`) VALUES
(101, '2014-02-16 22:35:20', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(102, '2014-02-16 22:35:20', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(103, '2014-02-16 22:35:20', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(104, '2014-02-16 22:35:20', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(105, '2014-02-16 22:55:31', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(106, '2014-02-16 22:55:31', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(107, '2014-02-16 23:03:34', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(108, '2014-02-16 23:03:34', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(109, '2014-02-16 23:08:39', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(110, '2014-02-16 23:08:40', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(111, '2014-02-16 23:56:20', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/page/2/', '', '', 0),
(112, '2014-02-17 11:49:12', '127.0.0.1', 'http://sarahtomlinson:8888/page/2/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/page/2/', '', '', 0),
(113, '2014-02-17 11:49:12', '127.0.0.1', '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(114, '2014-02-17 11:55:18', '127.0.0.1', 'http://sarahtomlinson:8888/page/2/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/page/2/', '', '', 0),
(115, '2014-02-17 11:55:18', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(116, '2014-02-17 11:55:47', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(117, '2014-02-17 11:55:47', '127.0.0.1', 'http://sarahtomlinson:8888/page/2/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/page/2/', '', '', 0),
(118, '2014-02-17 12:03:20', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(119, '2014-02-17 12:03:21', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(120, '2014-02-17 12:04:37', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(121, '2014-02-17 12:09:11', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(122, '2014-02-17 12:09:11', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(123, '2014-02-17 12:18:35', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/multiple-paragraph-post/', '', '', 0),
(124, '2014-02-17 12:18:46', '127.0.0.1', 'http://sarahtomlinson:8888/multiple-paragraph-post/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/image-post/', '', '', 0),
(125, '2014-02-17 12:18:51', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/multiple-paragraph-post/', '', '', 0),
(126, '2014-02-17 12:18:51', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(127, '2014-02-17 12:20:39', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/page/2/', '', '', 0),
(128, '2014-02-17 12:20:45', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(129, '2014-02-17 13:34:23', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(130, '2014-02-17 13:34:23', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(131, '2014-02-17 13:37:26', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(132, '2014-02-17 13:37:27', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(133, '2014-02-17 13:38:33', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/category/fiction/', '', '', 0),
(134, '2014-02-17 13:38:36', '127.0.0.1', 'http://sarahtomlinson:8888/category/fiction/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/category/blog/', '', '', 0),
(135, '2014-02-17 13:38:38', '127.0.0.1', 'http://sarahtomlinson:8888/category/blog/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/category/essays/', '', '', 0),
(136, '2014-02-17 13:38:40', '127.0.0.1', 'http://sarahtomlinson:8888/category/essays/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/category/blog/', '', '', 0),
(137, '2014-02-17 13:38:50', '127.0.0.1', 'http://sarahtomlinson:8888/category/blog/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(138, '2014-02-17 13:39:15', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(139, '2014-02-17 13:39:15', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(140, '2014-02-17 13:39:17', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/category/fiction/', '', '', 0),
(141, '2014-02-17 13:39:26', '127.0.0.1', 'http://sarahtomlinson:8888/category/fiction/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/bio/', '', '', 0),
(142, '2014-02-17 13:40:07', '127.0.0.1', 'http://sarahtomlinson:8888/bio/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/bio/', '', '', 0),
(143, '2014-02-17 13:40:21', '127.0.0.1', 'http://sarahtomlinson:8888/bio/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/bio/', '', '', 0),
(144, '2014-02-17 13:41:10', '127.0.0.1', 'http://sarahtomlinson:8888/bio/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(145, '2014-02-17 13:50:58', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(146, '2014-02-17 13:52:32', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(147, '2014-02-17 13:55:44', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(148, '2014-02-17 13:55:47', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(149, '2014-02-17 13:55:50', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(150, '2014-02-17 13:56:47', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(151, '2014-02-17 13:56:48', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(152, '2014-02-17 13:59:36', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(153, '2014-02-17 13:59:37', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(154, '2014-02-17 14:00:12', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(155, '2014-02-17 14:00:17', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(156, '2014-02-17 14:08:52', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(157, '2014-02-17 14:08:52', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(158, '2014-02-17 14:09:18', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(159, '2014-02-17 14:09:19', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(160, '2014-02-17 14:10:31', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(161, '2014-02-17 14:18:44', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(162, '2014-02-17 14:19:05', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(163, '2014-02-17 14:19:45', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(164, '2014-02-17 14:19:46', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(165, '2014-02-17 14:20:18', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(166, '2014-02-17 14:20:43', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(167, '2014-02-17 23:49:46', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(168, '2014-02-25 04:18:11', '127.0.0.1', '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.117 Safari/537.36', 'http://sarahtomlinson:8888/wp-login.php?redirect_to=http%3A%2F%2Fsarahtomlinson%2Fwp-admin%2F&#038;reauth=1', '', '', 0),
(169, '2014-02-25 04:18:19', '127.0.0.1', 'http://sarahtomlinson:8888/wp-login.php?redirect_to=http%3A%2F%2Fsarahtomlinson%2Fwp-admin%2F&amp;reauth=1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.117 Safari/537.36', 'http://sarahtomlinson:8888/wp-login.php', '', '', 0),
(170, '2014-02-25 23:25:55', '127.0.0.1', '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.117 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(171, '2014-02-25 23:26:47', '127.0.0.1', '', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.117 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0),
(172, '2014-02-25 23:27:12', '127.0.0.1', 'http://sarahtomlinson:8888/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.117 Safari/537.36', 'http://sarahtomlinson:8888/category/fiction/', '', '', 0),
(173, '2014-02-25 23:27:15', '127.0.0.1', 'http://sarahtomlinson:8888/category/fiction/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.117 Safari/537.36', 'http://sarahtomlinson:8888/category/essays/', '', '', 0),
(174, '2014-02-25 23:27:17', '127.0.0.1', 'http://sarahtomlinson:8888/category/essays/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.117 Safari/537.36', 'http://sarahtomlinson:8888/category/journalism/', '', '', 0),
(175, '2014-02-25 23:27:21', '127.0.0.1', 'http://sarahtomlinson:8888/category/journalism/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.117 Safari/537.36', 'http://sarahtomlinson:8888/bio/', '', '', 0),
(176, '2014-02-25 23:27:24', '127.0.0.1', 'http://sarahtomlinson:8888/bio/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.117 Safari/537.36', 'http://sarahtomlinson:8888/category/blog/', '', '', 0),
(177, '2014-02-25 23:27:27', '127.0.0.1', 'http://sarahtomlinson:8888/category/blog/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.117 Safari/537.36', 'http://sarahtomlinson:8888/image-post/', '', '', 0),
(178, '2014-02-25 23:28:00', '127.0.0.1', 'http://sarahtomlinson:8888/category/blog/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.117 Safari/537.36', 'http://sarahtomlinson:8888/image-post/', '', '', 0),
(179, '2014-02-25 23:28:10', '127.0.0.1', 'http://sarahtomlinson:8888/image-post/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.117 Safari/537.36', 'http://sarahtomlinson:8888/', '', '', 0) ;

#
# End of data contents of table `ws__wsd_plugin_live_traffic`
# --------------------------------------------------------



#
# Delete any existing table `ws__wsd_plugin_scan`
#

DROP TABLE IF EXISTS `ws__wsd_plugin_scan`;


#
# Table structure of table `ws__wsd_plugin_scan`
#

CREATE TABLE `ws__wsd_plugin_scan` (
  `entryId` bigint(20) NOT NULL AUTO_INCREMENT,
  `scanId` int(11) NOT NULL,
  `filePath` varchar(1000) NOT NULL,
  `dateModified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `fileNotFound` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`entryId`),
  UNIQUE KEY `entryId_UNIQUE` (`entryId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `ws__wsd_plugin_scan`
#

#
# End of data contents of table `ws__wsd_plugin_scan`
# --------------------------------------------------------



#
# Delete any existing table `ws__wsd_plugin_scans`
#

DROP TABLE IF EXISTS `ws__wsd_plugin_scans`;


#
# Table structure of table `ws__wsd_plugin_scans`
#

CREATE TABLE `ws__wsd_plugin_scans` (
  `scanId` int(11) NOT NULL AUTO_INCREMENT,
  `scanStartDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `scanEndDate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `scanResult` int(11) NOT NULL DEFAULT '0',
  `failReason` varchar(5000) NOT NULL DEFAULT '',
  `scanType` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`scanId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `ws__wsd_plugin_scans`
#

#
# End of data contents of table `ws__wsd_plugin_scans`
# --------------------------------------------------------



#
# Delete any existing table `ws_commentmeta`
#

DROP TABLE IF EXISTS `ws_commentmeta`;


#
# Table structure of table `ws_commentmeta`
#

CREATE TABLE `ws_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `ws_commentmeta`
#

#
# End of data contents of table `ws_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `ws_comments`
#

DROP TABLE IF EXISTS `ws_comments`;


#
# Table structure of table `ws_comments`
#

CREATE TABLE `ws_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


#
# Data contents of table `ws_comments`
#
INSERT INTO `ws_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Mr WordPress', '', 'http://wordpress.org/', '', '2014-02-10 08:31:17', '2014-02-10 08:31:17', 'Hi, this is a comment.\nTo delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, '1', '', '', 0, 0) ;

#
# End of data contents of table `ws_comments`
# --------------------------------------------------------



#
# Delete any existing table `ws_duplicator_packages`
#

DROP TABLE IF EXISTS `ws_duplicator_packages`;


#
# Table structure of table `ws_duplicator_packages`
#

CREATE TABLE `ws_duplicator_packages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `hash` varchar(50) NOT NULL,
  `status` int(11) NOT NULL,
  `created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `owner` varchar(60) NOT NULL,
  `package` mediumblob NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;


#
# Data contents of table `ws_duplicator_packages`
#
INSERT INTO `ws_duplicator_packages` ( `id`, `name`, `hash`, `status`, `created`, `owner`, `package`) VALUES
(1, '20140226_sarahtomlinson', '530d9882049c24474140226073218', 100, '2014-02-26 07:32:18', 'epicsupreme', 'O:11:"DUP_Package":15:{s:2:"ID";i:1;s:4:"Name";s:23:"20140226_sarahtomlinson";s:4:"Hash";s:29:"530d9882049c24474140226073218";s:8:"NameHash";s:53:"20140226_sarahtomlinson_530d9882049c24474140226073218";s:7:"Version";s:5:"0.5.2";s:4:"Type";i:0;s:5:"Notes";s:0:"";s:9:"StorePath";s:75:"/Volumes/Donnie/Dropbox/2014 Projects/Sarah Tomlinson/SIte/wp-snapshots/tmp";s:8:"StoreURL";s:40:"http://sarahtomlinson:8888/wp-snapshots/";s:7:"Runtime";N;s:7:"ExeSize";N;s:7:"ZipSize";N;s:7:"Archive";O:11:"DUP_Archive":15:{s:10:"FilterDirs";s:0:"";s:10:"FilterExts";s:0:"";s:8:"FilterOn";i:0;s:4:"File";s:65:"20140226_sarahtomlinson_530d9882049c24474140226073218_archive.zip";s:6:"Format";s:3:"ZIP";s:7:"PackDir";s:58:"/Volumes/Donnie/Dropbox/2014 Projects/Sarah Tomlinson/SIte";s:8:"DirCount";i:0;s:9:"FileCount";i:0;s:9:"LinkCount";i:0;s:4:"Size";i:29750118;s:11:"BigFileList";a:0:{}s:15:"InvalidFileList";a:0:{}s:10:"\0*\0Package";O:11:"DUP_Package":15:{s:2:"ID";i:1;s:4:"Name";s:23:"20140226_sarahtomlinson";s:4:"Hash";s:29:"530d9882049c24474140226073218";s:8:"NameHash";s:53:"20140226_sarahtomlinson_530d9882049c24474140226073218";s:7:"Version";s:5:"0.5.2";s:4:"Type";i:0;s:5:"Notes";s:0:"";s:9:"StorePath";s:75:"/Volumes/Donnie/Dropbox/2014 Projects/Sarah Tomlinson/SIte/wp-snapshots/tmp";s:8:"StoreURL";s:35:"http://sarahtomlinson/wp-snapshots/";s:7:"Runtime";N;s:7:"ExeSize";N;s:7:"ZipSize";N;s:7:"Archive";O:11:"DUP_Archive":15:{s:10:"FilterDirs";s:0:"";s:10:"FilterExts";s:0:"";s:8:"FilterOn";i:0;s:4:"File";s:65:"20140226_sarahtomlinson_530d9882049c24474140226073218_archive.zip";s:6:"Format";s:3:"ZIP";s:7:"PackDir";s:58:"/Volumes/Donnie/Dropbox/2014 Projects/Sarah Tomlinson/SIte";s:8:"DirCount";i:0;s:9:"FileCount";i:0;s:9:"LinkCount";i:0;s:4:"Size";i:29750118;s:11:"BigFileList";a:0:{}s:15:"InvalidFileList";a:0:{}s:10:"\0*\0Package";r:27;s:28:"\0DUP_Archive\0filterDirsArray";a:0:{}s:28:"\0DUP_Archive\0filterExtsArray";a:0:{}}s:9:"Installer";O:13:"DUP_Installer":11:{s:4:"File";s:67:"20140226_sarahtomlinson_530d9882049c24474140226073218_installer.php";s:4:"Size";i:418329;s:10:"OptsDBHost";s:0:"";s:10:"OptsDBName";s:0:"";s:10:"OptsDBUser";s:0:"";s:12:"OptsSSLAdmin";i:0;s:12:"OptsSSLLogin";i:0;s:11:"OptsCacheWP";i:0;s:13:"OptsCachePath";i:0;s:10:"OptsURLNew";s:0:"";s:10:"\0*\0Package";r:27;}s:8:"Database";O:12:"DUP_Database":9:{s:4:"Type";s:5:"MySQL";s:4:"Size";i:660648;s:4:"File";s:66:"20140226_sarahtomlinson_530d9882049c24474140226073218_database.sql";s:4:"Path";N;s:12:"FilterTables";s:0:"";s:8:"FilterOn";i:0;s:4:"Name";N;s:10:"\0*\0Package";r:27;s:25:"\0DUP_Database\0dbStorePath";s:142:"/Volumes/Donnie/Dropbox/2014 Projects/Sarah Tomlinson/SIte/wp-snapshots/tmp/20140226_sarahtomlinson_530d9882049c24474140226073218_database.sql";}}s:28:"\0DUP_Archive\0filterDirsArray";a:0:{}s:28:"\0DUP_Archive\0filterExtsArray";a:0:{}}s:9:"Installer";O:13:"DUP_Installer":11:{s:4:"File";s:67:"20140226_sarahtomlinson_530d9882049c24474140226073218_installer.php";s:4:"Size";i:418329;s:10:"OptsDBHost";s:0:"";s:10:"OptsDBName";s:0:"";s:10:"OptsDBUser";s:0:"";s:12:"OptsSSLAdmin";i:0;s:12:"OptsSSLLogin";i:0;s:11:"OptsCacheWP";i:0;s:13:"OptsCachePath";i:0;s:10:"OptsURLNew";s:0:"";s:10:"\0*\0Package";r:27;}s:8:"Database";O:12:"DUP_Database":9:{s:4:"Type";s:5:"MySQL";s:4:"Size";i:660648;s:4:"File";s:66:"20140226_sarahtomlinson_530d9882049c24474140226073218_database.sql";s:4:"Path";N;s:12:"FilterTables";s:0:"";s:8:"FilterOn";i:0;s:4:"Name";N;s:10:"\0*\0Package";r:27;s:25:"\0DUP_Database\0dbStorePath";s:142:"/Volumes/Donnie/Dropbox/2014 Projects/Sarah Tomlinson/SIte/wp-snapshots/tmp/20140226_sarahtomlinson_530d9882049c24474140226073218_database.sql";}}') ;

#
# End of data contents of table `ws_duplicator_packages`
# --------------------------------------------------------



#
# Delete any existing table `ws_links`
#

DROP TABLE IF EXISTS `ws_links`;


#
# Table structure of table `ws_links`
#

CREATE TABLE `ws_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `ws_links`
#

#
# End of data contents of table `ws_links`
# --------------------------------------------------------



#
# Delete any existing table `ws_options`
#

DROP TABLE IF EXISTS `ws_options`;


#
# Table structure of table `ws_options`
#

CREATE TABLE `ws_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=789 DEFAULT CHARSET=utf8;


#
# Data contents of table `ws_options`
#
INSERT INTO `ws_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://sarahtomlinson:8888', 'yes'),
(2, 'blogname', 'Sarah Tomlinson', 'yes'),
(3, 'blogdescription', 'Writer • Editor • Duchess of Rock', 'yes'),
(4, 'users_can_register', '0', 'yes'),
(5, 'admin_email', 'gregattack@gmail.com', 'yes'),
(6, 'start_of_week', '1', 'yes'),
(7, 'use_balanceTags', '0', 'yes'),
(8, 'use_smilies', '1', 'yes'),
(9, 'require_name_email', '1', 'yes'),
(10, 'comments_notify', '1', 'yes'),
(11, 'posts_per_rss', '10', 'yes'),
(12, 'rss_use_excerpt', '0', 'yes'),
(13, 'mailserver_url', 'mail.example.com', 'yes'),
(14, 'mailserver_login', 'login@example.com', 'yes'),
(15, 'mailserver_pass', 'password', 'yes'),
(16, 'mailserver_port', '110', 'yes'),
(17, 'default_category', '1', 'yes'),
(18, 'default_comment_status', 'open', 'yes'),
(19, 'default_ping_status', 'open', 'yes'),
(20, 'default_pingback_flag', '0', 'yes'),
(21, 'posts_per_page', '3', 'yes'),
(22, 'date_format', 'F j, Y', 'yes'),
(23, 'time_format', 'g:i a', 'yes'),
(24, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(25, 'links_recently_updated_prepend', '<em>', 'yes'),
(26, 'links_recently_updated_append', '</em>', 'yes'),
(27, 'links_recently_updated_time', '120', 'yes'),
(28, 'comment_moderation', '0', 'yes'),
(29, 'moderation_notify', '1', 'yes'),
(30, 'permalink_structure', '/%postname%/', 'yes'),
(31, 'gzipcompression', '0', 'yes'),
(32, 'hack_file', '0', 'yes'),
(33, 'blog_charset', 'UTF-8', 'yes'),
(34, 'moderation_keys', '', 'no'),
(35, 'active_plugins', 'a:17:{i:0;s:45:"acf-flexible-content/acf-flexible-content.php";i:1;s:27:"acf-gallery/acf-gallery.php";i:2;s:37:"acf-options-page/acf-options-page.php";i:3;s:29:"acf-repeater/acf-repeater.php";i:4;s:33:"admin-menu-editor/menu-editor.php";i:5;s:30:"advanced-custom-fields/acf.php";i:6;s:43:"all-in-one-seo-pack/all_in_one_seo_pack.php";i:7;s:39:"disable-admin-bar/disable-admin-bar.php";i:8;s:37:"disable-comments/disable-comments.php";i:9;s:25:"duplicator/duplicator.php";i:10;s:29:"gravityforms/gravityforms.php";i:11;s:59:"intuitive-custom-post-order/intuitive-custom-post-order.php";i:12;s:66:"really-simple-twitter-feed-widget/really_simple_twitter_widget.php";i:13;s:14:"types/wpcf.php";i:14;s:28:"wp-example-content/magic.php";i:15;s:39:"wp-migrate-db-pro/wp-migrate-db-pro.php";i:16;s:26:"wp-security-scan/index.php";}', 'yes'),
(36, 'home', 'http://sarahtomlinson:8888', 'yes'),
(37, 'category_base', '', 'yes'),
(38, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(39, 'advanced_edit', '0', 'yes'),
(40, 'comment_max_links', '2', 'yes'),
(41, 'gmt_offset', '0', 'yes'),
(42, 'default_email_category', '1', 'yes'),
(43, 'recently_edited', '', 'no'),
(44, 'template', 'name', 'yes'),
(45, 'stylesheet', 'name', 'yes'),
(46, 'comment_whitelist', '1', 'yes'),
(47, 'blacklist_keys', '', 'no'),
(48, 'comment_registration', '0', 'yes'),
(49, 'html_type', 'text/html', 'yes'),
(50, 'use_trackback', '0', 'yes'),
(51, 'default_role', 'subscriber', 'yes'),
(52, 'db_version', '26691', 'yes'),
(53, 'uploads_use_yearmonth_folders', '1', 'yes'),
(54, 'upload_path', '', 'yes'),
(55, 'blog_public', '0', 'yes'),
(56, 'default_link_category', '2', 'yes'),
(57, 'show_on_front', 'posts', 'yes'),
(58, 'tag_base', '', 'yes'),
(59, 'show_avatars', '1', 'yes'),
(60, 'avatar_rating', 'G', 'yes'),
(61, 'upload_url_path', '', 'yes'),
(62, 'thumbnail_size_w', '150', 'yes'),
(63, 'thumbnail_size_h', '150', 'yes'),
(64, 'thumbnail_crop', '1', 'yes'),
(65, 'medium_size_w', '300', 'yes'),
(66, 'medium_size_h', '300', 'yes'),
(67, 'avatar_default', 'mystery', 'yes'),
(68, 'large_size_w', '1024', 'yes'),
(69, 'large_size_h', '1024', 'yes'),
(70, 'image_default_link_type', 'file', 'yes'),
(71, 'image_default_size', '', 'yes'),
(72, 'image_default_align', '', 'yes'),
(73, 'close_comments_for_old_posts', '0', 'yes'),
(74, 'close_comments_days_old', '14', 'yes'),
(75, 'thread_comments', '1', 'yes'),
(76, 'thread_comments_depth', '5', 'yes'),
(77, 'page_comments', '0', 'yes'),
(78, 'comments_per_page', '50', 'yes'),
(79, 'default_comments_page', 'newest', 'yes'),
(80, 'comment_order', 'asc', 'yes'),
(81, 'sticky_posts', 'a:0:{}', 'yes'),
(82, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(83, 'widget_text', 'a:0:{}', 'yes'),
(84, 'widget_rss', 'a:0:{}', 'yes'),
(85, 'uninstall_plugins', 'a:2:{s:26:"wp-security-scan/index.php";a:2:{i:0;s:9:"WsdPlugin";i:1;s:9:"uninstall";}s:42:"sitepush/classes/class-sitepush-plugin.php";a:2:{i:0;s:14:"SitePushPlugin";i:1;s:9:"uninstall";}}', 'no'),
(86, 'timezone_string', '', 'yes'),
(87, 'page_for_posts', '0', 'yes'),
(88, 'page_on_front', '0', 'yes'),
(89, 'default_post_format', '0', 'yes'),
(90, 'link_manager_enabled', '0', 'yes'),
(91, 'initial_db_version', '26691', 'yes'),
(92, 'ws_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(93, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(94, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'sidebars_widgets', 'a:4:{s:19:"wp_inactive_widgets";a:0:{}s:15:"sidebar-widgets";a:5:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:10:"archives-2";i:3;s:12:"categories-2";i:4;s:6:"meta-2";}s:7:"twitter";a:1:{i:0;s:27:"reallysimpletwitterwidget-2";}s:13:"array_version";i:3;}', 'yes'),
(99, 'cron', 'a:8:{i:1393455907;a:1:{s:26:"wssPlugin_WpScanCheckState";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:2:"1m";s:4:"args";a:0:{}s:8:"interval";i:60;}}}i:1393456494;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1393457527;a:3:{s:28:"wps_check_admin_install_file";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}s:28:"wps_check_admin_upgrade_file";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}s:24:"wps_cleanup_live_traffic";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1393461127;a:1:{s:20:"wps_check_user_admin";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:2:"8h";s:4:"args";a:0:{}s:8:"interval";i:28800;}}}i:1393485420;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1393489878;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1393489894;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(112, 'can_compress_scripts', '1', 'yes') ;
INSERT INTO `ws_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(127, 'current_theme', '[project-name]', 'yes'),
(128, 'theme_mods_{name}', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1392021323;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:15:"sidebar-widgets";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(129, 'theme_switched', '', 'yes'),
(130, 'recently_activated', 'a:0:{}', 'yes'),
(132, 'acf_version', '4.3.4', 'yes'),
(133, 'WPS_KEEP_NUM_ENTRIES_LT', '500', 'yes'),
(134, 'WPS_REFRESH_RATE_AJAX_LT', '10', 'yes'),
(135, 'wps_plugin_enable_live_traffic', '1', 'yes'),
(136, 'wps_can_run_tasks', '1', 'yes'),
(138, 'wps_plugin_settings', 'a:13:{s:17:"fix_hideWpVersion";a:3:{s:4:"name";s:17:"fix_hideWpVersion";s:5:"value";i:1;s:4:"desc";s:55:"Hide WordPress version for all users but administrators";}s:34:"fix_removeWpMetaGeneratorsFrontend";a:3:{s:4:"name";s:34:"fix_removeWpMetaGeneratorsFrontend";s:5:"value";i:1;s:4:"desc";s:83:"Remove various meta tags generators from the blog\'s head tag for non-administrators";}s:31:"fix_removeReallySimpleDiscovery";a:3:{s:4:"name";s:31:"fix_removeReallySimpleDiscovery";s:5:"value";i:1;s:4:"desc";s:55:"Remove Really Simple Discovery meta tags from front-end";}s:27:"fix_removeWindowsLiveWriter";a:3:{s:4:"name";s:27:"fix_removeWindowsLiveWriter";s:5:"value";i:1;s:4:"desc";s:51:"Remove Windows Live Writer meta tags from front-end";}s:25:"fix_disableErrorReporting";a:3:{s:4:"name";s:25:"fix_disableErrorReporting";s:5:"value";i:1;s:4:"desc";s:61:"Disable error reporting (php + db) for all but administrators";}s:32:"fix_removeCoreUpdateNotification";a:3:{s:4:"name";s:32:"fix_removeCoreUpdateNotification";s:5:"value";i:1;s:4:"desc";s:73:"Remove core update notifications from back-end for all but administrators";}s:35:"fix_removePluginUpdateNotifications";a:3:{s:4:"name";s:35:"fix_removePluginUpdateNotifications";s:5:"value";i:1;s:4:"desc";s:50:"Remove plug-ins update notifications from back-end";}s:34:"fix_removeThemeUpdateNotifications";a:3:{s:4:"name";s:34:"fix_removeThemeUpdateNotifications";s:5:"value";i:1;s:4:"desc";s:48:"Remove themes update notifications from back-end";}s:41:"fix_removeLoginErrorNotificationsFrontEnd";a:3:{s:4:"name";s:41:"fix_removeLoginErrorNotificationsFrontEnd";s:5:"value";i:1;s:4:"desc";s:47:"Remove login error notifications from front-end";}s:26:"fix_hideAdminNotifications";a:3:{s:4:"name";s:26:"fix_hideAdminNotifications";s:5:"value";i:1;s:4:"desc";s:39:"Hide admin notifications for non admins";}s:27:"fix_preventDirectoryListing";a:3:{s:4:"name";s:27:"fix_preventDirectoryListing";s:5:"value";i:1;s:4:"desc";s:153:"Try to create the index.php file in the wp-content, wp-content/plugins, wp-content/themes and wp-content/uploads directories to prevent directory listing";}s:28:"fix_removeWpVersionFromLinks";a:3:{s:4:"name";s:28:"fix_removeWpVersionFromLinks";s:5:"value";i:1;s:4:"desc";s:38:"Remove the version parameter from urls";}s:27:"fix_emptyReadmeFileFromRoot";a:3:{s:4:"name";s:27:"fix_emptyReadmeFileFromRoot";s:5:"value";i:1;s:4:"desc";s:65:"Empty the content of the readme.html file from the root directory";}}', 'yes'),
(139, 'wps_plugin_wp_scan', 'a:5:{s:10:"SCAN_STATE";i:3;s:13:"SCAN_PROGRESS";i:0;s:11:"SCAN_RESULT";i:2;s:9:"SCAN_TYPE";i:0;s:7:"SCAN_ID";i:0;}', 'yes'),
(140, 'ws_menu_editor', 'a:13:{s:22:"hide_advanced_settings";b:1;s:11:"custom_menu";N;s:18:"first_install_time";i:1392021128;s:21:"display_survey_notice";b:1;s:17:"plugin_db_version";i:140;s:24:"security_logging_enabled";b:0;s:17:"menu_config_scope";s:6:"global";s:13:"plugin_access";s:14:"manage_options";s:15:"allowed_user_id";N;s:28:"plugins_page_allowed_user_id";N;s:27:"show_deprecated_hide_button";N;s:37:"dashboard_hiding_confirmation_enabled";b:1;s:23:"show_plugin_menu_notice";b:0;}', 'yes'),
(141, 'disable_comments_options', 'a:4:{s:19:"disabled_post_types";a:3:{i:0;s:4:"post";i:1;s:4:"page";i:2;s:10:"attachment";}s:17:"remove_everywhere";b:1;s:9:"permanent";b:0;s:10:"db_version";i:5;}', 'yes'),
(142, 'hicpo_options', 'a:1:{s:7:"objects";a:3:{i:0;s:4:"post";i:1;s:4:"page";i:2;s:10:"attachment";}}', 'yes'),
(144, 'wpcf-messages', 'a:0:{}', 'yes'),
(145, 'aioseop_options', 'a:60:{s:12:"aiosp_donate";N;s:16:"aiosp_home_title";N;s:22:"aiosp_home_description";s:0:"";s:20:"aiosp_togglekeywords";i:0;s:19:"aiosp_home_keywords";N;s:9:"aiosp_can";i:1;s:20:"aiosp_rewrite_titles";i:1;s:20:"aiosp_force_rewrites";i:1;s:24:"aiosp_use_original_title";i:0;s:16:"aiosp_cap_titles";i:1;s:14:"aiosp_cap_cats";i:1;s:23:"aiosp_page_title_format";s:27:"%page_title% | %blog_title%";s:23:"aiosp_post_title_format";s:27:"%post_title% | %blog_title%";s:27:"aiosp_category_title_format";s:31:"%category_title% | %blog_title%";s:26:"aiosp_archive_title_format";s:21:"%date% | %blog_title%";s:25:"aiosp_author_title_format";s:23:"%author% | %blog_title%";s:22:"aiosp_tag_title_format";s:20:"%tag% | %blog_title%";s:25:"aiosp_search_title_format";s:23:"%search% | %blog_title%";s:24:"aiosp_description_format";s:13:"%description%";s:22:"aiosp_404_title_format";s:33:"Nothing found for %request_words%";s:18:"aiosp_paged_format";s:14:" - Part %page%";s:17:"aiosp_enablecpost";s:2:"on";s:19:"aiosp_cpostadvanced";i:0;s:17:"aiosp_cpostactive";a:2:{i:0;s:4:"post";i:1;s:4:"page";}s:18:"aiosp_cpostnoindex";a:0:{}s:19:"aiosp_cpostnofollow";a:0:{}s:17:"aiosp_cposttitles";i:0;s:21:"aiosp_posttypecolumns";a:2:{i:0;s:4:"post";i:1;s:4:"page";}s:15:"aiosp_admin_bar";s:2:"on";s:23:"aiosp_custom_menu_order";s:2:"on";s:19:"aiosp_google_verify";s:0:"";s:17:"aiosp_bing_verify";s:0:"";s:22:"aiosp_pinterest_verify";s:0:"";s:22:"aiosp_google_publisher";s:0:"";s:28:"aiosp_google_disable_profile";i:0;s:20:"aiosp_google_connect";N;s:25:"aiosp_google_analytics_id";N;s:32:"aiosp_ga_use_universal_analytics";i:0;s:15:"aiosp_ga_domain";N;s:21:"aiosp_ga_multi_domain";i:0;s:28:"aiosp_ga_display_advertising";N;s:22:"aiosp_ga_exclude_users";N;s:29:"aiosp_ga_track_outbound_links";i:0;s:20:"aiosp_use_categories";i:0;s:26:"aiosp_use_tags_as_keywords";i:1;s:32:"aiosp_dynamic_postspage_keywords";i:1;s:22:"aiosp_category_noindex";i:1;s:26:"aiosp_archive_date_noindex";i:1;s:28:"aiosp_archive_author_noindex";i:1;s:18:"aiosp_tags_noindex";i:0;s:20:"aiosp_search_noindex";i:0;s:27:"aiosp_generate_descriptions";i:1;s:33:"aiosp_hide_paginated_descriptions";i:0;s:20:"aiosp_unprotect_meta";i:0;s:14:"aiosp_ex_pages";s:0:"";s:20:"aiosp_post_meta_tags";s:0:"";s:20:"aiosp_page_meta_tags";s:0:"";s:21:"aiosp_front_meta_tags";s:0:"";s:20:"aiosp_home_meta_tags";s:0:"";s:12:"aiosp_do_log";N;}', 'yes'),
(146, 'gravityformsaddon_gravityformswebapi_version', '1.0', 'yes'),
(147, 'rg_form_version', '1.8.4', 'yes'),
(150, 'WSD-RSS-WGT-DISPLAY', 'yes', 'yes'),
(155, 'wps_live_traffic_entries', '179', 'yes'),
(158, 'theme_mods_twentyfourteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1392021326;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:18:"orphaned_widgets_1";a:5:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:10:"archives-2";i:3;s:12:"categories-2";i:4;s:6:"meta-2";}s:18:"orphaned_widgets_2";a:0:{}s:18:"orphaned_widgets_3";a:0:{}}}}', 'yes'),
(159, 'theme_mods_name', 'a:2:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}}', 'yes'),
(190, 'sandboxes', 'a:0:{}', 'yes'),
(202, 'sitepush_options', 'a:22:{s:11:"last_update";d:1392024376.6694900989532470703125;s:10:"sites_conf";N;s:8:"dbs_conf";N;s:15:"domain_map_conf";N;s:8:"timezone";N;s:18:"debug_output_level";N;s:10:"capability";s:17:"edit_others_posts";s:16:"admin_capability";s:16:"activate_plugins";s:9:"cache_key";N;s:16:"plugin_activates";N;s:18:"plugin_deactivates";N;s:11:"backup_path";N;s:16:"backup_keep_time";i:10;s:10:"rsync_path";s:14:"/usr/bin/rsync";s:9:"dont_sync";s:47:".git,.svn,.htaccess,tmp,wp-config.php,.DS_Store";s:10:"mysql_path";s:36:"/Applications/MAMP/Library/bin/mysql";s:14:"mysqldump_path";s:40:"/Applications/MAMP/Library/bin/mysqldump";s:6:"accept";N;s:13:"fix_site_urls";N;s:25:"only_admins_login_to_live";N;s:26:"non_admin_exclude_comments";N;s:25:"non_admin_exclude_options";N;}', 'yes'),
(241, 'wps_plugin_feed_data', 'O:8:"stdClass":2:{s:7:"expires";i:1392026280;s:4:"data";s:3462:"<ul><li><h4><a href="http://www.acunetix.com/blog/web-security-zone/trusted-remote-server-side-request-forgery-attacks/" target="_blank" title="Posted on February 7, 2014 | 9:33 am">Server Side Request Forgery (SSRF)</a></h4><p>A Server Side Request Forgery (SSRF) attack gives an attacker the ability to use your web application to send requests t <a href="http://www.acunetix.com/blog/web-security-zone/trusted-remote-server-side-request-forgery-attacks/" target="_blank" title="Read all article">[...]</a></p></li><li><h4><a href="http://www.acunetix.com/blog/web-security-zone/automatic-detection-xxe-vulnerabilities-openid-implementations-using-acunetix-acumonitor/" target="_blank" title="Posted on February 6, 2014 | 10:09 am">Automatic detection of XXE vulnerabilities in OpenID implementations using Acunetix AcuMonitor</a></h4><p>Reginaldo Silva recently uncovered a very interesting bug affecting Facebook (and received $33,500 for this discovery).  <a href="http://www.acunetix.com/blog/web-security-zone/automatic-detection-xxe-vulnerabilities-openid-implementations-using-acunetix-acumonitor/" target="_blank" title="Read all article">[...]</a></p></li><li><h4><a href="http://www.acunetix.com/blog/releases/new-functionality-vulnerabilities-mediawiki-joomla-oracle/" target="_blank" title="Posted on February 6, 2014 | 10:05 am">Acunetix Web Vulnerability Scanner v9, build 20140206 includes several new tests for vulnerabilities on well-known web applications</a></h4><p>Acunetix Web Vulnerability Scanner version 9, build 20140206 is able to scan WordPress more efficiently, and includes va <a href="http://www.acunetix.com/blog/releases/new-functionality-vulnerabilities-mediawiki-joomla-oracle/" target="_blank" title="Read all article">[...]</a></p></li><li><h4><a href="http://www.acunetix.com/blog/releases/new-compliance-report-wvs-v9/" target="_blank" title="Posted on December 16, 2013 | 11:14 am">Acunetix Web Vulnerability Scanner v9, build 20131216 includes a new PCI 3.0 compliance report and several new tests</a></h4><p>Acunetix Web Vulnerability Scanner version 9, build 20131216 includes a new compliance report to cover the latest versio <a href="http://www.acunetix.com/blog/releases/new-compliance-report-wvs-v9/" target="_blank" title="Read all article">[...]</a></p></li><li><h4><a href="http://www.acunetix.com/blog/releases/new-security-tests-added-acunetix-web-vulnerability-scanner/" target="_blank" title="Posted on December 16, 2013 | 11:12 am">New Security Checks Added to Acunetix Web Vulnerability Scanner</a></h4><p>The latest build of Acunetix Web Vulnerability Scanner includes a lot of changes and new security tests. Here is a short <a href="http://www.acunetix.com/blog/releases/new-security-tests-added-acunetix-web-vulnerability-scanner/" target="_blank" title="Read all article">[...]</a></p></li></ul><div style="border-top: solid 1px #ccc; margin-top: 4px; padding: 2px 0;"><p style="margin: 5px 0 0 0; padding: 0 0; line-height: normal; overflow: hidden;"><a href="http://feeds.acunetix.com/acunetixwebapplicationsecurityblog"\r\n                                style="float: left; display: block; width: 50%; text-align: right; margin-left: 30px;\r\n                                padding-right: 22px; background: url(http://sarahtomlinson:8888/wp-content/plugins/wp-security-scan/res/images/rss.png) no-repeat right center;"\r\n                                target="_blank">Follow us on RSS</a></p></div>";}', 'yes'),
(258, 'wpmdb_settings', 'a:7:{s:11:"max_request";i:1048576;s:3:"key";s:32:"ILeqvq4V7QC3lJ1nKpQkZmibRJVe+/7G";s:10:"allow_pull";b:1;s:10:"allow_push";b:1;s:8:"profiles";a:0:{}s:7:"licence";s:36:"0eb1d030-cb66-43fa-80f0-2c82a2aa1886";s:10:"verify_ssl";b:0;}', 'yes'),
(322, 'duplicator_version_plugin', '0.5.2', 'yes'),
(329, 'duplicator_settings', 'a:8:{s:7:"version";s:5:"0.5.2";s:18:"uninstall_settings";b:1;s:15:"uninstall_files";b:1;s:16:"uninstall_tables";b:1;s:13:"package_debug";b:0;s:17:"package_mysqldump";b:0;s:22:"package_mysqldump_path";s:0:"";s:17:"package_zip_flush";b:0;}', 'yes'),
(341, 'duplicator_ui_view_state', 'a:2:{s:14:"dup-wpnotice01";b:1;s:16:"dup-notice01-chk";s:1:"1";}', 'yes'),
(357, 'rewrite_rules', 'a:96:{s:42:"wp-types-group/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:52:"wp-types-group/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:72:"wp-types-group/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:67:"wp-types-group/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:67:"wp-types-group/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:35:"wp-types-group/([^/]+)/trackback/?$";s:41:"index.php?wp-types-group=$matches[1]&tb=1";s:43:"wp-types-group/([^/]+)/page/?([0-9]{1,})/?$";s:54:"index.php?wp-types-group=$matches[1]&paged=$matches[2]";s:50:"wp-types-group/([^/]+)/comment-page-([0-9]{1,})/?$";s:54:"index.php?wp-types-group=$matches[1]&cpage=$matches[2]";s:35:"wp-types-group/([^/]+)(/[0-9]+)?/?$";s:53:"index.php?wp-types-group=$matches[1]&page=$matches[2]";s:31:"wp-types-group/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:41:"wp-types-group/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:61:"wp-types-group/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:"wp-types-group/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:56:"wp-types-group/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:47:"wp-types-user-group/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:57:"wp-types-user-group/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:77:"wp-types-user-group/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"wp-types-user-group/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"wp-types-user-group/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:40:"wp-types-user-group/([^/]+)/trackback/?$";s:46:"index.php?wp-types-user-group=$matches[1]&tb=1";s:48:"wp-types-user-group/([^/]+)/page/?([0-9]{1,})/?$";s:59:"index.php?wp-types-user-group=$matches[1]&paged=$matches[2]";s:55:"wp-types-user-group/([^/]+)/comment-page-([0-9]{1,})/?$";s:59:"index.php?wp-types-user-group=$matches[1]&cpage=$matches[2]";s:40:"wp-types-user-group/([^/]+)(/[0-9]+)?/?$";s:58:"index.php?wp-types-user-group=$matches[1]&page=$matches[2]";s:36:"wp-types-user-group/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:46:"wp-types-user-group/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:66:"wp-types-user-group/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"wp-types-user-group/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"wp-types-user-group/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)(/[0-9]+)?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:20:"([^/]+)(/[0-9]+)?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";}', 'yes'),
(361, 'category_children', 'a:0:{}', 'yes'),
(363, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(474, 'widget_reallysimpletwitterwidget', 'a:2:{i:2;a:29:{s:12:"consumer_key";s:22:"gcQppmQUpSkeIzjQcCrFUg";s:15:"consumer_secret";s:43:"BF6hq92Zdg8vW1SQPzgrFnuQ22mqp597GmV8BoqfTpc";s:12:"access_token";s:50:"106970651-Q4h93NyJZlGuiOuquQr15wTmSBxxI0v5qtf7N3VW";s:19:"access_token_secret";s:40:"XCnytEJ9CSQuoGosODFejyfu4w02pBpnPRNVxJiI";s:8:"username";s:13:"duchessofrock";s:3:"num";s:1:"5";s:9:"skip_text";s:0:"";s:12:"skip_replies";b:1;s:13:"skip_retweets";b:0;s:5:"title";s:8:"Twtitter";s:10:"title_icon";b:0;s:15:"title_thumbnail";b:0;s:10:"link_title";b:1;s:9:"link_user";b:0;s:14:"link_user_text";s:17:"See me on Twitter";s:13:"button_follow";b:0;s:18:"button_follow_text";s:10:"Follow @me";s:6:"linked";s:0:"";s:6:"update";b:1;s:11:"date_format";s:3:"M j";s:9:"thumbnail";b:0;s:18:"thumbnail_retweets";b:0;s:10:"hyperlinks";b:1;s:17:"replace_link_text";s:0:"";s:13:"twitter_users";b:1;s:17:"link_target_blank";b:0;s:5:"debug";b:0;s:17:"erase_cached_data";b:0;s:11:"encode_utf8";b:0;}s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `ws_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(486, 'twitter_data_duchessofrock_5_valid', 'a:19:{i:0;a:22:{s:10:"created_at";s:30:"Tue Feb 25 03:52:03 +0000 2014";s:2:"id";i:438159430316609536;s:6:"id_str";s:18:"438159430316609536";s:4:"text";s:136:"AWP friends, are you a female memoirist w daddy issues, or know an attendee who is? We seek a writer for our panel, Thurs am @ 10:30. xx";s:6:"source";s:3:"web";s:9:"truncated";b:0;s:21:"in_reply_to_status_id";N;s:25:"in_reply_to_status_id_str";N;s:19:"in_reply_to_user_id";N;s:23:"in_reply_to_user_id_str";N;s:23:"in_reply_to_screen_name";N;s:4:"user";a:39:{s:2:"id";i:35583247;s:6:"id_str";s:8:"35583247";s:4:"name";s:15:"Sarah Tomlinson";s:11:"screen_name";s:13:"duchessofrock";s:8:"location";s:13:"LA / Brooklyn";s:11:"description";s:67:"I feel the same way about writing that you felt about Breaking Bad.";s:3:"url";s:22:"http://t.co/NoNeYVwP4x";s:8:"entities";a:2:{s:3:"url";a:1:{s:4:"urls";a:1:{i:0;a:4:{s:3:"url";s:22:"http://t.co/NoNeYVwP4x";s:12:"expanded_url";s:30:"http://sarahtomlinson:8888.com";s:11:"display_url";s:18:"sarahtomlinson.com";s:7:"indices";a:2:{i:0;i:0;i:1;i:22;}}}}s:11:"description";a:1:{s:4:"urls";a:0:{}}}s:9:"protected";b:0;s:15:"followers_count";i:314;s:13:"friends_count";i:161;s:12:"listed_count";i:8;s:10:"created_at";s:30:"Sun Apr 26 22:23:48 +0000 2009";s:16:"favourites_count";i:30;s:10:"utc_offset";i:-28800;s:9:"time_zone";s:26:"Pacific Time (US & Canada)";s:11:"geo_enabled";b:0;s:8:"verified";b:0;s:14:"statuses_count";i:256;s:4:"lang";s:2:"en";s:20:"contributors_enabled";b:0;s:13:"is_translator";b:0;s:22:"is_translation_enabled";b:0;s:24:"profile_background_color";s:6:"C0DEED";s:28:"profile_background_image_url";s:48:"http://abs.twimg.com/images/themes/theme1/bg.png";s:34:"profile_background_image_url_https";s:49:"https://abs.twimg.com/images/themes/theme1/bg.png";s:23:"profile_background_tile";b:0;s:17:"profile_image_url";s:84:"http://pbs.twimg.com/profile_images/239465319/SarahTomlinsonLZ1T3809_copy_normal.jpg";s:23:"profile_image_url_https";s:85:"https://pbs.twimg.com/profile_images/239465319/SarahTomlinsonLZ1T3809_copy_normal.jpg";s:18:"profile_link_color";s:6:"0084B4";s:28:"profile_sidebar_border_color";s:6:"C0DEED";s:26:"profile_sidebar_fill_color";s:6:"DDEEF6";s:18:"profile_text_color";s:6:"333333";s:28:"profile_use_background_image";b:1;s:15:"default_profile";b:1;s:21:"default_profile_image";b:0;s:9:"following";b:0;s:19:"follow_request_sent";b:0;s:13:"notifications";b:0;}s:3:"geo";N;s:11:"coordinates";N;s:5:"place";N;s:12:"contributors";N;s:13:"retweet_count";i:0;s:14:"favorite_count";i:0;s:8:"entities";a:4:{s:8:"hashtags";a:0:{}s:7:"symbols";a:0:{}s:4:"urls";a:0:{}s:13:"user_mentions";a:0:{}}s:9:"favorited";b:0;s:9:"retweeted";b:0;s:4:"lang";s:2:"en";}i:1;a:22:{s:10:"created_at";s:30:"Mon Feb 24 23:06:22 +0000 2014";s:2:"id";i:438087536330563584;s:6:"id_str";s:18:"438087536330563584";s:4:"text";s:137:"Love is confirming your foibles to a magazine fact checker so your daughter can publish an essay about her relationship w you. #thanksdad";s:6:"source";s:3:"web";s:9:"truncated";b:0;s:21:"in_reply_to_status_id";N;s:25:"in_reply_to_status_id_str";N;s:19:"in_reply_to_user_id";N;s:23:"in_reply_to_user_id_str";N;s:23:"in_reply_to_screen_name";N;s:4:"user";a:39:{s:2:"id";i:35583247;s:6:"id_str";s:8:"35583247";s:4:"name";s:15:"Sarah Tomlinson";s:11:"screen_name";s:13:"duchessofrock";s:8:"location";s:13:"LA / Brooklyn";s:11:"description";s:67:"I feel the same way about writing that you felt about Breaking Bad.";s:3:"url";s:22:"http://t.co/NoNeYVwP4x";s:8:"entities";a:2:{s:3:"url";a:1:{s:4:"urls";a:1:{i:0;a:4:{s:3:"url";s:22:"http://t.co/NoNeYVwP4x";s:12:"expanded_url";s:30:"http://sarahtomlinson:8888.com";s:11:"display_url";s:18:"sarahtomlinson.com";s:7:"indices";a:2:{i:0;i:0;i:1;i:22;}}}}s:11:"description";a:1:{s:4:"urls";a:0:{}}}s:9:"protected";b:0;s:15:"followers_count";i:314;s:13:"friends_count";i:161;s:12:"listed_count";i:8;s:10:"created_at";s:30:"Sun Apr 26 22:23:48 +0000 2009";s:16:"favourites_count";i:30;s:10:"utc_offset";i:-28800;s:9:"time_zone";s:26:"Pacific Time (US & Canada)";s:11:"geo_enabled";b:0;s:8:"verified";b:0;s:14:"statuses_count";i:256;s:4:"lang";s:2:"en";s:20:"contributors_enabled";b:0;s:13:"is_translator";b:0;s:22:"is_translation_enabled";b:0;s:24:"profile_background_color";s:6:"C0DEED";s:28:"profile_background_image_url";s:48:"http://abs.twimg.com/images/themes/theme1/bg.png";s:34:"profile_background_image_url_https";s:49:"https://abs.twimg.com/images/themes/theme1/bg.png";s:23:"profile_background_tile";b:0;s:17:"profile_image_url";s:84:"http://pbs.twimg.com/profile_images/239465319/SarahTomlinsonLZ1T3809_copy_normal.jpg";s:23:"profile_image_url_https";s:85:"https://pbs.twimg.com/profile_images/239465319/SarahTomlinsonLZ1T3809_copy_normal.jpg";s:18:"profile_link_color";s:6:"0084B4";s:28:"profile_sidebar_border_color";s:6:"C0DEED";s:26:"profile_sidebar_fill_color";s:6:"DDEEF6";s:18:"profile_text_color";s:6:"333333";s:28:"profile_use_background_image";b:1;s:15:"default_profile";b:1;s:21:"default_profile_image";b:0;s:9:"following";b:0;s:19:"follow_request_sent";b:0;s:13:"notifications";b:0;}s:3:"geo";N;s:11:"coordinates";N;s:5:"place";N;s:12:"contributors";N;s:13:"retweet_count";i:1;s:14:"favorite_count";i:2;s:8:"entities";a:4:{s:8:"hashtags";a:1:{i:0;a:2:{s:4:"text";s:9:"thanksdad";s:7:"indices";a:2:{i:0;i:127;i:1;i:137;}}}s:7:"symbols";a:0:{}s:4:"urls";a:0:{}s:13:"user_mentions";a:0:{}}s:9:"favorited";b:0;s:9:"retweeted";b:0;s:4:"lang";s:2:"en";}i:2;a:23:{s:10:"created_at";s:30:"Sun Feb 23 02:37:05 +0000 2014";s:2:"id";i:437415788539310081;s:6:"id_str";s:18:"437415788539310081";s:4:"text";s:77:"Coyote (+ imagine the scent of blooming night jasmine) http://t.co/1yYK76h1dg";s:6:"source";s:59:"<a href="http://instagram.com" rel="nofollow">Instagram</a>";s:9:"truncated";b:0;s:21:"in_reply_to_status_id";N;s:25:"in_reply_to_status_id_str";N;s:19:"in_reply_to_user_id";N;s:23:"in_reply_to_user_id_str";N;s:23:"in_reply_to_screen_name";N;s:4:"user";a:39:{s:2:"id";i:35583247;s:6:"id_str";s:8:"35583247";s:4:"name";s:15:"Sarah Tomlinson";s:11:"screen_name";s:13:"duchessofrock";s:8:"location";s:13:"LA / Brooklyn";s:11:"description";s:67:"I feel the same way about writing that you felt about Breaking Bad.";s:3:"url";s:22:"http://t.co/NoNeYVwP4x";s:8:"entities";a:2:{s:3:"url";a:1:{s:4:"urls";a:1:{i:0;a:4:{s:3:"url";s:22:"http://t.co/NoNeYVwP4x";s:12:"expanded_url";s:30:"http://sarahtomlinson:8888.com";s:11:"display_url";s:18:"sarahtomlinson.com";s:7:"indices";a:2:{i:0;i:0;i:1;i:22;}}}}s:11:"description";a:1:{s:4:"urls";a:0:{}}}s:9:"protected";b:0;s:15:"followers_count";i:314;s:13:"friends_count";i:161;s:12:"listed_count";i:8;s:10:"created_at";s:30:"Sun Apr 26 22:23:48 +0000 2009";s:16:"favourites_count";i:30;s:10:"utc_offset";i:-28800;s:9:"time_zone";s:26:"Pacific Time (US & Canada)";s:11:"geo_enabled";b:0;s:8:"verified";b:0;s:14:"statuses_count";i:256;s:4:"lang";s:2:"en";s:20:"contributors_enabled";b:0;s:13:"is_translator";b:0;s:22:"is_translation_enabled";b:0;s:24:"profile_background_color";s:6:"C0DEED";s:28:"profile_background_image_url";s:48:"http://abs.twimg.com/images/themes/theme1/bg.png";s:34:"profile_background_image_url_https";s:49:"https://abs.twimg.com/images/themes/theme1/bg.png";s:23:"profile_background_tile";b:0;s:17:"profile_image_url";s:84:"http://pbs.twimg.com/profile_images/239465319/SarahTomlinsonLZ1T3809_copy_normal.jpg";s:23:"profile_image_url_https";s:85:"https://pbs.twimg.com/profile_images/239465319/SarahTomlinsonLZ1T3809_copy_normal.jpg";s:18:"profile_link_color";s:6:"0084B4";s:28:"profile_sidebar_border_color";s:6:"C0DEED";s:26:"profile_sidebar_fill_color";s:6:"DDEEF6";s:18:"profile_text_color";s:6:"333333";s:28:"profile_use_background_image";b:1;s:15:"default_profile";b:1;s:21:"default_profile_image";b:0;s:9:"following";b:0;s:19:"follow_request_sent";b:0;s:13:"notifications";b:0;}s:3:"geo";N;s:11:"coordinates";N;s:5:"place";N;s:12:"contributors";N;s:13:"retweet_count";i:0;s:14:"favorite_count";i:0;s:8:"entities";a:4:{s:8:"hashtags";a:0:{}s:7:"symbols";a:0:{}s:4:"urls";a:1:{i:0;a:4:{s:3:"url";s:22:"http://t.co/1yYK76h1dg";s:12:"expanded_url";s:34:"http://instagram.com/p/kvfiSRQMKr/";s:11:"display_url";s:27:"instagram.com/p/kvfiSRQMKr/";s:7:"indices";a:2:{i:0;i:55;i:1;i:77;}}}s:13:"user_mentions";a:0:{}}s:9:"favorited";b:0;s:9:"retweeted";b:0;s:18:"possibly_sensitive";b:0;s:4:"lang";s:2:"en";}i:3;a:24:{s:10:"created_at";s:30:"Sun Feb 23 00:57:32 +0000 2014";s:2:"id";i:437390737911476224;s:6:"id_str";s:18:"437390737911476224";s:4:"text";s:142:"RT @seanhdoyle: The new issue of @theatlasreview is now alive in the world. I am in it with so many lovely people. Get some here --- http:/…";s:6:"source";s:82:"<a href="http://twitter.com/download/iphone" rel="nofollow">Twitter for iPhone</a>";s:9:"truncated";b:0;s:21:"in_reply_to_status_id";N;s:25:"in_reply_to_status_id_str";N;s:19:"in_reply_to_user_id";N;s:23:"in_reply_to_user_id_str";N;s:23:"in_reply_to_screen_name";N;s:4:"user";a:39:{s:2:"id";i:35583247;s:6:"id_str";s:8:"35583247";s:4:"name";s:15:"Sarah Tomlinson";s:11:"screen_name";s:13:"duchessofrock";s:8:"location";s:13:"LA / Brooklyn";s:11:"description";s:67:"I feel the same way about writing that you felt about Breaking Bad.";s:3:"url";s:22:"http://t.co/NoNeYVwP4x";s:8:"entities";a:2:{s:3:"url";a:1:{s:4:"urls";a:1:{i:0;a:4:{s:3:"url";s:22:"http://t.co/NoNeYVwP4x";s:12:"expanded_url";s:30:"http://sarahtomlinson:8888.com";s:11:"display_url";s:18:"sarahtomlinson.com";s:7:"indices";a:2:{i:0;i:0;i:1;i:22;}}}}s:11:"description";a:1:{s:4:"urls";a:0:{}}}s:9:"protected";b:0;s:15:"followers_count";i:314;s:13:"friends_count";i:161;s:12:"listed_count";i:8;s:10:"created_at";s:30:"Sun Apr 26 22:23:48 +0000 2009";s:16:"favourites_count";i:30;s:10:"utc_offset";i:-28800;s:9:"time_zone";s:26:"Pacific Time (US & Canada)";s:11:"geo_enabled";b:0;s:8:"verified";b:0;s:14:"statuses_count";i:256;s:4:"lang";s:2:"en";s:20:"contributors_enabled";b:0;s:13:"is_translator";b:0;s:22:"is_translation_enabled";b:0;s:24:"profile_background_color";s:6:"C0DEED";s:28:"profile_background_image_url";s:48:"http://abs.twimg.com/images/themes/theme1/bg.png";s:34:"profile_background_image_url_https";s:49:"https://abs.twimg.com/images/themes/theme1/bg.png";s:23:"profile_background_tile";b:0;s:17:"profile_image_url";s:84:"http://pbs.twimg.com/profile_images/239465319/SarahTomlinsonLZ1T3809_copy_normal.jpg";s:23:"profile_image_url_https";s:85:"https://pbs.twimg.com/profile_images/239465319/SarahTomlinsonLZ1T3809_copy_normal.jpg";s:18:"profile_link_color";s:6:"0084B4";s:28:"profile_sidebar_border_color";s:6:"C0DEED";s:26:"profile_sidebar_fill_color";s:6:"DDEEF6";s:18:"profile_text_color";s:6:"333333";s:28:"profile_use_background_image";b:1;s:15:"default_profile";b:1;s:21:"default_profile_image";b:0;s:9:"following";b:0;s:19:"follow_request_sent";b:0;s:13:"notifications";b:0;}s:3:"geo";N;s:11:"coordinates";N;s:5:"place";N;s:12:"contributors";N;s:16:"retweeted_status";a:23:{s:10:"created_at";s:30:"Sat Feb 22 19:35:11 +0000 2014";s:2:"id";i:437309616071147521;s:6:"id_str";s:18:"437309616071147521";s:4:"text";s:139:"The new issue of @theatlasreview is now alive in the world. I am in it with so many lovely people. Get some here --- http://t.co/Pu66At6j6s";s:6:"source";s:3:"web";s:9:"truncated";b:0;s:21:"in_reply_to_status_id";N;s:25:"in_reply_to_status_id_str";N;s:19:"in_reply_to_user_id";N;s:23:"in_reply_to_user_id_str";N;s:23:"in_reply_to_screen_name";N;s:4:"user";a:40:{s:2:"id";i:27440554;s:6:"id_str";s:8:"27440554";s:4:"name";s:12:"Sean H Doyle";s:11:"screen_name";s:10:"seanhdoyle";s:8:"location";s:8:"Brooklyn";s:11:"description";s:31:"I like to smash words together.";s:3:"url";s:22:"http://t.co/HrpgogltZq";s:8:"entities";a:2:{s:3:"url";a:1:{s:4:"urls";a:1:{i:0;a:4:{s:3:"url";s:22:"http://t.co/HrpgogltZq";s:12:"expanded_url";s:22:"http://seanhdoyle.com/";s:11:"display_url";s:14:"seanhdoyle.com";s:7:"indices";a:2:{i:0;i:0;i:1;i:22;}}}}s:11:"description";a:1:{s:4:"urls";a:0:{}}}s:9:"protected";b:0;s:15:"followers_count";i:950;s:13:"friends_count";i:568;s:12:"listed_count";i:31;s:10:"created_at";s:30:"Sun Mar 29 15:17:44 +0000 2009";s:16:"favourites_count";i:9330;s:10:"utc_offset";i:-18000;s:9:"time_zone";s:26:"Eastern Time (US & Canada)";s:11:"geo_enabled";b:1;s:8:"verified";b:0;s:14:"statuses_count";i:16072;s:4:"lang";s:2:"en";s:20:"contributors_enabled";b:0;s:13:"is_translator";b:0;s:22:"is_translation_enabled";b:0;s:24:"profile_background_color";s:6:"131516";s:28:"profile_background_image_url";s:79:"http://pbs.twimg.com/profile_background_images/378800000167818258/FZRUmTjq.jpeg";s:34:"profile_background_image_url_https";s:80:"https://pbs.twimg.com/profile_background_images/378800000167818258/FZRUmTjq.jpeg";s:23:"profile_background_tile";b:1;s:17:"profile_image_url";s:75:"http://pbs.twimg.com/profile_images/437313075444588544/wbVB7eGK_normal.jpeg";s:23:"profile_image_url_https";s:76:"https://pbs.twimg.com/profile_images/437313075444588544/wbVB7eGK_normal.jpeg";s:18:"profile_banner_url";s:57:"https://pbs.twimg.com/profile_banners/27440554/1348090725";s:18:"profile_link_color";s:6:"009999";s:28:"profile_sidebar_border_color";s:6:"FFFFFF";s:26:"profile_sidebar_fill_color";s:6:"EFEFEF";s:18:"profile_text_color";s:6:"333333";s:28:"profile_use_background_image";b:1;s:15:"default_profile";b:0;s:21:"default_profile_image";b:0;s:9:"following";b:0;s:19:"follow_request_sent";b:0;s:13:"notifications";b:0;}s:3:"geo";N;s:11:"coordinates";N;s:5:"place";N;s:12:"contributors";N;s:13:"retweet_count";i:5;s:14:"favorite_count";i:8;s:8:"entities";a:4:{s:8:"hashtags";a:0:{}s:7:"symbols";a:0:{}s:4:"urls";a:1:{i:0;a:4:{s:3:"url";s:22:"http://t.co/Pu66At6j6s";s:12:"expanded_url";s:36:"http://theatlasreview.bigcartel.com/";s:11:"display_url";s:28:"theatlasreview.bigcartel.com";s:7:"indices";a:2:{i:0;i:117;i:1;i:139;}}}s:13:"user_mentions";a:1:{i:0;a:5:{s:11:"screen_name";s:14:"theatlasreview";s:4:"name";s:16:"The Atlas Review";s:2:"id";i:633259700;s:6:"id_str";s:9:"633259700";s:7:"indices";a:2:{i:0;i:17;i:1;i:32;}}}}s:9:"favorited";b:0;s:9:"retweeted";b:0;s:18:"possibly_sensitive";b:0;s:4:"lang";s:2:"en";}s:13:"retweet_count";i:5;s:14:"favorite_count";i:0;s:8:"entities";a:4:{s:8:"hashtags";a:0:{}s:7:"symbols";a:0:{}s:4:"urls";a:1:{i:0;a:4:{s:3:"url";s:22:"http://t.co/Pu66At6j6s";s:12:"expanded_url";s:36:"http://theatlasreview.bigcartel.com/";s:11:"display_url";s:28:"theatlasreview.bigcartel.com";s:7:"indices";a:2:{i:0;i:139;i:1;i:140;}}}s:13:"user_mentions";a:2:{i:0;a:5:{s:11:"screen_name";s:10:"seanhdoyle";s:4:"name";s:12:"Sean H Doyle";s:2:"id";i:27440554;s:6:"id_str";s:8:"27440554";s:7:"indices";a:2:{i:0;i:3;i:1;i:14;}}i:1;a:5:{s:11:"screen_name";s:14:"theatlasreview";s:4:"name";s:16:"The Atlas Review";s:2:"id";i:633259700;s:6:"id_str";s:9:"633259700";s:7:"indices";a:2:{i:0;i:33;i:1;i:48;}}}}s:9:"favorited";b:0;s:9:"retweeted";b:0;s:18:"possibly_sensitive";b:0;s:4:"lang";s:2:"en";}i:4;a:23:{s:10:"created_at";s:30:"Sat Feb 22 10:47:53 +0000 2014";s:2:"id";i:437176912793042944;s:6:"id_str";s:18:"437176912793042944";s:4:"text";s:33:"LA Skyline http://t.co/cBFlG0lxq9";s:6:"source";s:59:"<a href="http://instagram.com" rel="nofollow">Instagram</a>";s:9:"truncated";b:0;s:21:"in_reply_to_status_id";N;s:25:"in_reply_to_status_id_str";N;s:19:"in_reply_to_user_id";N;s:23:"in_reply_to_user_id_str";N;s:23:"in_reply_to_screen_name";N;s:4:"user";a:39:{s:2:"id";i:35583247;s:6:"id_str";s:8:"35583247";s:4:"name";s:15:"Sarah Tomlinson";s:11:"screen_name";s:13:"duchessofrock";s:8:"location";s:13:"LA / Brooklyn";s:11:"description";s:67:"I feel the same way about writing that you felt about Breaking Bad.";s:3:"url";s:22:"http://t.co/NoNeYVwP4x";s:8:"entities";a:2:{s:3:"url";a:1:{s:4:"urls";a:1:{i:0;a:4:{s:3:"url";s:22:"http://t.co/NoNeYVwP4x";s:12:"expanded_url";s:30:"http://sarahtomlinson:8888.com";s:11:"display_url";s:18:"sarahtomlinson.com";s:7:"indices";a:2:{i:0;i:0;i:1;i:22;}}}}s:11:"description";a:1:{s:4:"urls";a:0:{}}}s:9:"protected";b:0;s:15:"followers_count";i:314;s:13:"friends_count";i:161;s:12:"listed_count";i:8;s:10:"created_at";s:30:"Sun Apr 26 22:23:48 +0000 2009";s:16:"favourites_count";i:30;s:10:"utc_offset";i:-28800;s:9:"time_zone";s:26:"Pacific Time (US & Canada)";s:11:"geo_enabled";b:0;s:8:"verified";b:0;s:14:"statuses_count";i:256;s:4:"lang";s:2:"en";s:20:"contributors_enabled";b:0;s:13:"is_translator";b:0;s:22:"is_translation_enabled";b:0;s:24:"profile_background_color";s:6:"C0DEED";s:28:"profile_background_image_url";s:48:"http://abs.twimg.com/images/themes/theme1/bg.png";s:34:"profile_background_image_url_https";s:49:"https://abs.twimg.com/images/themes/theme1/bg.png";s:23:"profile_background_tile";b:0;s:17:"profile_image_url";s:84:"http://pbs.twimg.com/profile_images/239465319/SarahTomlinsonLZ1T3809_copy_normal.jpg";s:23:"profile_image_url_https";s:85:"https://pbs.twimg.com/profile_images/239465319/SarahTomlinsonLZ1T3809_copy_normal.jpg";s:18:"profile_link_color";s:6:"0084B4";s:28:"profile_sidebar_border_color";s:6:"C0DEED";s:26:"profile_sidebar_fill_color";s:6:"DDEEF6";s:18:"profile_text_color";s:6:"333333";s:28:"profile_use_background_image";b:1;s:15:"default_profile";b:1;s:21:"default_profile_image";b:0;s:9:"following";b:0;s:19:"follow_request_sent";b:0;s:13:"notifications";b:0;}s:3:"geo";N;s:11:"coordinates";N;s:5:"place";N;s:12:"contributors";N;s:13:"retweet_count";i:0;s:14:"favorite_count";i:0;s:8:"entities";a:4:{s:8:"hashtags";a:0:{}s:7:"symbols";a:0:{}s:4:"urls";a:1:{i:0;a:4:{s:3:"url";s:22:"http://t.co/cBFlG0lxq9";s:12:"expanded_url";s:34:"http://instagram.com/p/kty6FeQMBO/";s:11:"display_url";s:27:"instagram.com/p/kty6FeQMBO/";s:7:"indices";a:2:{i:0;i:11;i:1;i:33;}}}s:13:"user_mentions";a:0:{}}s:9:"favorited";b:0;s:9:"retweeted";b:0;s:18:"possibly_sensitive";b:0;s:4:"lang";s:2:"et";}i:5;a:24:{s:10:"created_at";s:30:"Fri Feb 21 03:06:08 +0000 2014";s:2:"id";i:436698324091953152;s:6:"id_str";s:18:"436698324091953152";s:4:"text";s:142:"RT @AlysiaAbbott: Every daughter must bury her father, "marble-heavy, a bag full of God."Lady memoirists with daddy issues at #AWP14: http:…";s:6:"source";s:3:"web";s:9:"truncated";b:0;s:21:"in_reply_to_status_id";N;s:25:"in_reply_to_status_id_str";N;s:19:"in_reply_to_user_id";N;s:23:"in_reply_to_user_id_str";N;s:23:"in_reply_to_screen_name";N;s:4:"user";a:39:{s:2:"id";i:35583247;s:6:"id_str";s:8:"35583247";s:4:"name";s:15:"Sarah Tomlinson";s:11:"screen_name";s:13:"duchessofrock";s:8:"location";s:13:"LA / Brooklyn";s:11:"description";s:67:"I feel the same way about writing that you felt about Breaking Bad.";s:3:"url";s:22:"http://t.co/NoNeYVwP4x";s:8:"entities";a:2:{s:3:"url";a:1:{s:4:"urls";a:1:{i:0;a:4:{s:3:"url";s:22:"http://t.co/NoNeYVwP4x";s:12:"expanded_url";s:30:"http://sarahtomlinson:8888.com";s:11:"display_url";s:18:"sarahtomlinson.com";s:7:"indices";a:2:{i:0;i:0;i:1;i:22;}}}}s:11:"description";a:1:{s:4:"urls";a:0:{}}}s:9:"protected";b:0;s:15:"followers_count";i:314;s:13:"friends_count";i:161;s:12:"listed_count";i:8;s:10:"created_at";s:30:"Sun Apr 26 22:23:48 +0000 2009";s:16:"favourites_count";i:30;s:10:"utc_offset";i:-28800;s:9:"time_zone";s:26:"Pacific Time (US & Canada)";s:11:"geo_enabled";b:0;s:8:"verified";b:0;s:14:"statuses_count";i:256;s:4:"lang";s:2:"en";s:20:"contributors_enabled";b:0;s:13:"is_translator";b:0;s:22:"is_translation_enabled";b:0;s:24:"profile_background_color";s:6:"C0DEED";s:28:"profile_background_image_url";s:48:"http://abs.twimg.com/images/themes/theme1/bg.png";s:34:"profile_background_image_url_https";s:49:"https://abs.twimg.com/images/themes/theme1/bg.png";s:23:"profile_background_tile";b:0;s:17:"profile_image_url";s:84:"http://pbs.twimg.com/profile_images/239465319/SarahTomlinsonLZ1T3809_copy_normal.jpg";s:23:"profile_image_url_https";s:85:"https://pbs.twimg.com/profile_images/239465319/SarahTomlinsonLZ1T3809_copy_normal.jpg";s:18:"profile_link_color";s:6:"0084B4";s:28:"profile_sidebar_border_color";s:6:"C0DEED";s:26:"profile_sidebar_fill_color";s:6:"DDEEF6";s:18:"profile_text_color";s:6:"333333";s:28:"profile_use_background_image";b:1;s:15:"default_profile";b:1;s:21:"default_profile_image";b:0;s:9:"following";b:0;s:19:"follow_request_sent";b:0;s:13:"notifications";b:0;}s:3:"geo";N;s:11:"coordinates";N;s:5:"place";N;s:12:"contributors";N;s:16:"retweeted_status";a:23:{s:10:"created_at";s:30:"Thu Feb 20 03:24:47 +0000 2014";s:2:"id";i:436340631271927808;s:6:"id_str";s:18:"436340631271927808";s:4:"text";s:138:"Every daughter must bury her father, "marble-heavy, a bag full of God."Lady memoirists with daddy issues at #AWP14: http://t.co/p9fXUWNQhe";s:6:"source";s:3:"web";s:9:"truncated";b:0;s:21:"in_reply_to_status_id";N;s:25:"in_reply_to_status_id_str";N;s:19:"in_reply_to_user_id";N;s:23:"in_reply_to_user_id_str";N;s:23:"in_reply_to_screen_name";N;s:4:"user";a:40:{s:2:"id";i:482060961;s:6:"id_str";s:9:"482060961";s:4:"name";s:13:"Alysia Abbott";s:11:"screen_name";s:12:"AlysiaAbbott";s:8:"location";s:9:"Cambridge";s:11:"description";s:138:"Wrote Fairyland: A Memoir of My Father with @wwnorton, in paperback 6/14. Native San Franciscan. Displaced New Yorker. Happiest on trains.";s:3:"url";s:23:"https://t.co/bCckayXnQ1";s:8:"entities";a:2:{s:3:"url";a:1:{s:4:"urls";a:1:{i:0;a:4:{s:3:"url";s:23:"https://t.co/bCckayXnQ1";s:12:"expanded_url";s:35:"https://alysiaabbott.contently.com/";s:11:"display_url";s:26:"alysiaabbott.contently.com";s:7:"indices";a:2:{i:0;i:0;i:1;i:23;}}}}s:11:"description";a:1:{s:4:"urls";a:0:{}}}s:9:"protected";b:0;s:15:"followers_count";i:704;s:13:"friends_count";i:675;s:12:"listed_count";i:17;s:10:"created_at";s:30:"Fri Feb 03 13:45:52 +0000 2012";s:16:"favourites_count";i:1291;s:10:"utc_offset";N;s:9:"time_zone";N;s:11:"geo_enabled";b:0;s:8:"verified";b:0;s:14:"statuses_count";i:2344;s:4:"lang";s:2:"en";s:20:"contributors_enabled";b:0;s:13:"is_translator";b:0;s:22:"is_translation_enabled";b:0;s:24:"profile_background_color";s:6:"C0DEED";s:28:"profile_background_image_url";s:94:"http://pbs.twimg.com/profile_background_images/839860076/f3275e0bd382eb959d5575cb2cf6bcd4.jpeg";s:34:"profile_background_image_url_https";s:95:"https://pbs.twimg.com/profile_background_images/839860076/f3275e0bd382eb959d5575cb2cf6bcd4.jpeg";s:23:"profile_background_tile";b:1;s:17:"profile_image_url";s:75:"http://pbs.twimg.com/profile_images/411637403426639872/bKPsFkmC_normal.jpeg";s:23:"profile_image_url_https";s:76:"https://pbs.twimg.com/profile_images/411637403426639872/bKPsFkmC_normal.jpeg";s:18:"profile_banner_url";s:58:"https://pbs.twimg.com/profile_banners/482060961/1379818843";s:18:"profile_link_color";s:6:"0084B4";s:28:"profile_sidebar_border_color";s:6:"FFFFFF";s:26:"profile_sidebar_fill_color";s:6:"DDEEF6";s:18:"profile_text_color";s:6:"333333";s:28:"profile_use_background_image";b:1;s:15:"default_profile";b:0;s:21:"default_profile_image";b:0;s:9:"following";b:0;s:19:"follow_request_sent";b:0;s:13:"notifications";b:0;}s:3:"geo";N;s:11:"coordinates";N;s:5:"place";N;s:12:"contributors";N;s:13:"retweet_count";i:1;s:14:"favorite_count";i:1;s:8:"entities";a:4:{s:8:"hashtags";a:1:{i:0;a:2:{s:4:"text";s:5:"AWP14";s:7:"indices";a:2:{i:0;i:108;i:1;i:114;}}}s:7:"symbols";a:0:{}s:4:"urls";a:1:{i:0;a:4:{s:3:"url";s:22:"http://t.co/p9fXUWNQhe";s:12:"expanded_url";s:26:"http://tinyurl.com/jvv4s2p";s:11:"display_url";s:19:"tinyurl.com/jvv4s2p";s:7:"indices";a:2:{i:0;i:116;i:1;i:138;}}}s:13:"user_mentions";a:0:{}}s:9:"favorited";b:0;s:9:"retweeted";b:0;s:18:"possibly_sensitive";b:0;s:4:"lang";s:2:"en";}s:13:"retweet_count";i:1;s:14:"favorite_count";i:0;s:8:"entities";a:4:{s:8:"hashtags";a:1:{i:0;a:2:{s:4:"text";s:5:"AWP14";s:7:"indices";a:2:{i:0;i:126;i:1;i:132;}}}s:7:"symbols";a:0:{}s:4:"urls";a:1:{i:0;a:4:{s:3:"url";s:22:"http://t.co/p9fXUWNQhe";s:12:"expanded_url";s:26:"http://tinyurl.com/jvv4s2p";s:11:"display_url";s:19:"tinyurl.com/jvv4s2p";s:7:"indices";a:2:{i:0;i:139;i:1;i:140;}}}s:13:"user_mentions";a:1:{i:0;a:5:{s:11:"screen_name";s:12:"AlysiaAbbott";s:4:"name";s:13:"Alysia Abbott";s:2:"id";i:482060961;s:6:"id_str";s:9:"482060961";s:7:"indices";a:2:{i:0;i:3;i:1;i:16;}}}}s:9:"favorited";b:0;s:9:"retweeted";b:0;s:18:"possibly_sensitive";b:0;s:4:"lang";s:2:"en";}i:6;a:23:{s:10:"created_at";s:30:"Fri Feb 14 05:22:00 +0000 2014";s:2:"id";i:434195800747696128;s:6:"id_str";s:18:"434195800747696128";s:4:"text";s:41:"Jack\'s first beach http://t.co/xUVbcEzkNW";s:6:"source";s:59:"<a href="http://instagram.com" rel="nofollow">Instagram</a>";s:9:"truncated";b:0;s:21:"in_reply_to_status_id";N;s:25:"in_reply_to_status_id_str";N;s:19:"in_reply_to_user_id";N;s:23:"in_reply_to_user_id_str";N;s:23:"in_reply_to_screen_name";N;s:4:"user";a:39:{s:2:"id";i:35583247;s:6:"id_str";s:8:"35583247";s:4:"name";s:15:"Sarah Tomlinson";s:11:"screen_name";s:13:"duchessofrock";s:8:"location";s:13:"LA / Brooklyn";s:11:"description";s:67:"I feel the same way about writing that you felt about Breaking Bad.";s:3:"url";s:22:"http://t.co/NoNeYVwP4x";s:8:"entities";a:2:{s:3:"url";a:1:{s:4:"urls";a:1:{i:0;a:4:{s:3:"url";s:22:"http://t.co/NoNeYVwP4x";s:12:"expanded_url";s:30:"http://sarahtomlinson:8888.com";s:11:"display_url";s:18:"sarahtomlinson.com";s:7:"indices";a:2:{i:0;i:0;i:1;i:22;}}}}s:11:"description";a:1:{s:4:"urls";a:0:{}}}s:9:"protected";b:0;s:15:"followers_count";i:314;s:13:"friends_count";i:161;s:12:"listed_count";i:8;s:10:"created_at";s:30:"Sun Apr 26 22:23:48 +0000 2009";s:16:"favourites_count";i:30;s:10:"utc_offset";i:-28800;s:9:"time_zone";s:26:"Pacific Time (US & Canada)";s:11:"geo_enabled";b:0;s:8:"verified";b:0;s:14:"statuses_count";i:256;s:4:"lang";s:2:"en";s:20:"contributors_enabled";b:0;s:13:"is_translator";b:0;s:22:"is_translation_enabled";b:0;s:24:"profile_background_color";s:6:"C0DEED";s:28:"profile_background_image_url";s:48:"http://abs.twimg.com/images/themes/theme1/bg.png";s:34:"profile_background_image_url_https";s:49:"https://abs.twimg.com/images/themes/theme1/bg.png";s:23:"profile_background_tile";b:0;s:17:"profile_image_url";s:84:"http://pbs.twimg.com/profile_images/239465319/SarahTomlinsonLZ1T3809_copy_normal.jpg";s:23:"profile_image_url_https";s:85:"https://pbs.twimg.com/profile_images/239465319/SarahTomlinsonLZ1T3809_copy_normal.jpg";s:18:"profile_link_color";s:6:"0084B4";s:28:"profile_sidebar_border_color";s:6:"C0DEED";s:26:"profile_sidebar_fill_color";s:6:"DDEEF6";s:18:"profile_text_color";s:6:"333333";s:28:"profile_use_background_image";b:1;s:15:"default_profile";b:1;s:21:"default_profile_image";b:0;s:9:"following";b:0;s:19:"follow_request_sent";b:0;s:13:"notifications";b:0;}s:3:"geo";N;s:11:"coordinates";N;s:5:"place";N;s:12:"contributors";N;s:13:"retweet_count";i:0;s:14:"favorite_count";i:0;s:8:"entities";a:4:{s:8:"hashtags";a:0:{}s:7:"symbols";a:0:{}s:4:"urls";a:1:{i:0;a:4:{s:3:"url";s:22:"http://t.co/xUVbcEzkNW";s:12:"expanded_url";s:34:"http://instagram.com/p/kYnQTrQMHD/";s:11:"display_url";s:27:"instagram.com/p/kYnQTrQMHD/";s:7:"indices";a:2:{i:0;i:19;i:1;i:41;}}}s:13:"user_mentions";a:0:{}}s:9:"favorited";b:0;s:9:"retweeted";b:0;s:18:"possibly_sensitive";b:0;s:4:"lang";s:2:"en";}i:7;a:22:{s:10:"created_at";s:30:"Fri Feb 14 04:01:45 +0000 2014";s:2:"id";i:434175605819441152;s:6:"id_str";s:18:"434175605819441152";s:4:"text";s:119:"Sweet Martin Sheen just told me Jack is a very handsome dog (and let on he\'s a Ramblin\' Jack Elliott fan). #lifeinthebu";s:6:"source";s:3:"web";s:9:"truncated";b:0;s:21:"in_reply_to_status_id";N;s:25:"in_reply_to_status_id_str";N;s:19:"in_reply_to_user_id";N;s:23:"in_reply_to_user_id_str";N;s:23:"in_reply_to_screen_name";N;s:4:"user";a:39:{s:2:"id";i:35583247;s:6:"id_str";s:8:"35583247";s:4:"name";s:15:"Sarah Tomlinson";s:11:"screen_name";s:13:"duchessofrock";s:8:"location";s:13:"LA / Brooklyn";s:11:"description";s:67:"I feel the same way about writing that you felt about Breaking Bad.";s:3:"url";s:22:"http://t.co/NoNeYVwP4x";s:8:"entities";a:2:{s:3:"url";a:1:{s:4:"urls";a:1:{i:0;a:4:{s:3:"url";s:22:"http://t.co/NoNeYVwP4x";s:12:"expanded_url";s:30:"http://sarahtomlinson:8888.com";s:11:"display_url";s:18:"sarahtomlinson.com";s:7:"indices";a:2:{i:0;i:0;i:1;i:22;}}}}s:11:"description";a:1:{s:4:"urls";a:0:{}}}s:9:"protected";b:0;s:15:"followers_count";i:314;s:13:"friends_count";i:161;s:12:"listed_count";i:8;s:10:"created_at";s:30:"Sun Apr 26 22:23:48 +0000 2009";s:16:"favourites_count";i:30;s:10:"utc_offset";i:-28800;s:9:"time_zone";s:26:"Pacific Time (US & Canada)";s:11:"geo_enabled";b:0;s:8:"verified";b:0;s:14:"statuses_count";i:256;s:4:"lang";s:2:"en";s:20:"contributors_enabled";b:0;s:13:"is_translator";b:0;s:22:"is_translation_enabled";b:0;s:24:"profile_background_color";s:6:"C0DEED";s:28:"profile_background_image_url";s:48:"http://abs.twimg.com/images/themes/theme1/bg.png";s:34:"profile_background_image_url_https";s:49:"https://abs.twimg.com/images/themes/theme1/bg.png";s:23:"profile_background_tile";b:0;s:17:"profile_image_url";s:84:"http://pbs.twimg.com/profile_images/239465319/SarahTomlinsonLZ1T3809_copy_normal.jpg";s:23:"profile_image_url_https";s:85:"https://pbs.twimg.com/profile_images/239465319/SarahTomlinsonLZ1T3809_copy_normal.jpg";s:18:"profile_link_color";s:6:"0084B4";s:28:"profile_sidebar_border_color";s:6:"C0DEED";s:26:"profile_sidebar_fill_color";s:6:"DDEEF6";s:18:"profile_text_color";s:6:"333333";s:28:"profile_use_background_image";b:1;s:15:"default_profile";b:1;s:21:"default_profile_image";b:0;s:9:"following";b:0;s:19:"follow_request_sent";b:0;s:13:"notifications";b:0;}s:3:"geo";N;s:11:"coordinates";N;s:5:"place";N;s:12:"contributors";N;s:13:"retweet_count";i:0;s:14:"favorite_count";i:0;s:8:"entities";a:4:{s:8:"hashtags";a:1:{i:0;a:2:{s:4:"text";s:11:"lifeinthebu";s:7:"indices";a:2:{i:0;i:107;i:1;i:119;}}}s:7:"symbols";a:0:{}s:4:"urls";a:0:{}s:13:"user_mentions";a:0:{}}s:9:"favorited";b:0;s:9:"retweeted";b:0;s:4:"lang";s:2:"en";}i:8;a:23:{s:10:"created_at";s:30:"Wed Feb 12 04:22:37 +0000 2014";s:2:"id";i:433456081155522560;s:6:"id_str";s:18:"433456081155522560";s:4:"text";s:139:"By 1971 Eve was suffering from a condition she termed squalid overboogie. - @VanityFair, yes! + Read @steffienelson: http://t.co/avLLowlb1G";s:6:"source";s:3:"web";s:9:"truncated";b:0;s:21:"in_reply_to_status_id";N;s:25:"in_reply_to_status_id_str";N;s:19:"in_reply_to_user_id";N;s:23:"in_reply_to_user_id_str";N;s:23:"in_reply_to_screen_name";N;s:4:"user";a:39:{s:2:"id";i:35583247;s:6:"id_str";s:8:"35583247";s:4:"name";s:15:"Sarah Tomlinson";s:11:"screen_name";s:13:"duchessofrock";s:8:"location";s:13:"LA / Brooklyn";s:11:"description";s:67:"I feel the same way about writing that you felt about Breaking Bad.";s:3:"url";s:22:"http://t.co/NoNeYVwP4x";s:8:"entities";a:2:{s:3:"url";a:1:{s:4:"urls";a:1:{i:0;a:4:{s:3:"url";s:22:"http://t.co/NoNeYVwP4x";s:12:"expanded_url";s:30:"http://sarahtomlinson:8888.com";s:11:"display_url";s:18:"sarahtomlinson.com";s:7:"indices";a:2:{i:0;i:0;i:1;i:22;}}}}s:11:"description";a:1:{s:4:"urls";a:0:{}}}s:9:"protected";b:0;s:15:"followers_count";i:314;s:13:"friends_count";i:161;s:12:"listed_count";i:8;s:10:"created_at";s:30:"Sun Apr 26 22:23:48 +0000 2009";s:16:"favourites_count";i:30;s:10:"utc_offset";i:-28800;s:9:"time_zone";s:26:"Pacific Time (US & Canada)";s:11:"geo_enabled";b:0;s:8:"verified";b:0;s:14:"statuses_count";i:256;s:4:"lang";s:2:"en";s:20:"contributors_enabled";b:0;s:13:"is_translator";b:0;s:22:"is_translation_enabled";b:0;s:24:"profile_background_color";s:6:"C0DEED";s:28:"profile_background_image_url";s:48:"http://abs.twimg.com/images/themes/theme1/bg.png";s:34:"profile_background_image_url_https";s:49:"https://abs.twimg.com/images/themes/theme1/bg.png";s:23:"profile_background_tile";b:0;s:17:"profile_image_url";s:84:"http://pbs.twimg.com/profile_images/239465319/SarahTomlinsonLZ1T3809_copy_normal.jpg";s:23:"profile_image_url_https";s:85:"https://pbs.twimg.com/profile_images/239465319/SarahTomlinsonLZ1T3809_copy_normal.jpg";s:18:"profile_link_color";s:6:"0084B4";s:28:"profile_sidebar_border_color";s:6:"C0DEED";s:26:"profile_sidebar_fill_color";s:6:"DDEEF6";s:18:"profile_text_color";s:6:"333333";s:28:"profile_use_background_image";b:1;s:15:"default_profile";b:1;s:21:"default_profile_image";b:0;s:9:"following";b:0;s:19:"follow_request_sent";b:0;s:13:"notifications";b:0;}s:3:"geo";N;s:11:"coordinates";N;s:5:"place";N;s:12:"contributors";N;s:13:"retweet_count";i:1;s:14:"favorite_count";i:0;s:8:"entities";a:4:{s:8:"hashtags";a:0:{}s:7:"symbols";a:0:{}s:4:"urls";a:1:{i:0;a:4:{s:3:"url";s:22:"http://t.co/avLLowlb1G";s:12:"expanded_url";s:42:"http://lareviewofbooks.org/essay/l-a-woman";s:11:"display_url";s:35:"lareviewofbooks.org/essay/l-a-woman";s:7:"indices";a:2:{i:0;i:117;i:1;i:139;}}}s:13:"user_mentions";a:2:{i:0;a:5:{s:11:"screen_name";s:10:"VanityFair";s:4:"name";s:11:"VANITY FAIR";s:2:"id";i:15279429;s:6:"id_str";s:8:"15279429";s:7:"indices";a:2:{i:0;i:76;i:1;i:87;}}i:1;a:5:{s:11:"screen_name";s:13:"steffienelson";s:4:"name";s:14:"Steffie Nelson";s:2:"id";i:2204252460;s:6:"id_str";s:10:"2204252460";s:7:"indices";a:2:{i:0;i:101;i:1;i:115;}}}}s:9:"favorited";b:0;s:9:"retweeted";b:0;s:18:"possibly_sensitive";b:0;s:4:"lang";s:2:"en";}i:9;a:23:{s:10:"created_at";s:30:"Mon Feb 10 07:10:14 +0000 2014";s:2:"id";i:432773487263219712;s:6:"id_str";s:18:"432773487263219712";s:4:"text";s:123:"Working in Malibu as a writer is so much better than when I used to work in Malibu a caterer. But… http://t.co/0twsFu9qsC";s:6:"source";s:59:"<a href="http://instagram.com" rel="nofollow">Instagram</a>";s:9:"truncated";b:0;s:21:"in_reply_to_status_id";N;s:25:"in_reply_to_status_id_str";N;s:19:"in_reply_to_user_id";N;s:23:"in_reply_to_user_id_str";N;s:23:"in_reply_to_screen_name";N;s:4:"user";a:39:{s:2:"id";i:35583247;s:6:"id_str";s:8:"35583247";s:4:"name";s:15:"Sarah Tomlinson";s:11:"screen_name";s:13:"duchessofrock";s:8:"location";s:13:"LA / Brooklyn";s:11:"description";s:67:"I feel the same way about writing that you felt about Breaking Bad.";s:3:"url";s:22:"http://t.co/NoNeYVwP4x";s:8:"entities";a:2:{s:3:"url";a:1:{s:4:"urls";a:1:{i:0;a:4:{s:3:"url";s:22:"http://t.co/NoNeYVwP4x";s:12:"expanded_url";s:30:"http://sarahtomlinson:8888.com";s:11:"display_url";s:18:"sarahtomlinson.com";s:7:"indices";a:2:{i:0;i:0;i:1;i:22;}}}}s:11:"description";a:1:{s:4:"urls";a:0:{}}}s:9:"protected";b:0;s:15:"followers_count";i:314;s:13:"friends_count";i:161;s:12:"listed_count";i:8;s:10:"created_at";s:30:"Sun Apr 26 22:23:48 +0000 2009";s:16:"favourites_count";i:30;s:10:"utc_offset";i:-28800;s:9:"time_zone";s:26:"Pacific Time (US & Canada)";s:11:"geo_enabled";b:0;s:8:"verified";b:0;s:14:"statuses_count";i:256;s:4:"lang";s:2:"en";s:20:"contributors_enabled";b:0;s:13:"is_translator";b:0;s:22:"is_translation_enabled";b:0;s:24:"profile_background_color";s:6:"C0DEED";s:28:"profile_background_image_url";s:48:"http://abs.twimg.com/images/themes/theme1/bg.png";s:34:"profile_background_image_url_https";s:49:"https://abs.twimg.com/images/themes/theme1/bg.png";s:23:"profile_background_tile";b:0;s:17:"profile_image_url";s:84:"http://pbs.twimg.com/profile_images/239465319/SarahTomlinsonLZ1T3809_copy_normal.jpg";s:23:"profile_image_url_https";s:85:"https://pbs.twimg.com/profile_images/239465319/SarahTomlinsonLZ1T3809_copy_normal.jpg";s:18:"profile_link_color";s:6:"0084B4";s:28:"profile_sidebar_border_color";s:6:"C0DEED";s:26:"profile_sidebar_fill_color";s:6:"DDEEF6";s:18:"profile_text_color";s:6:"333333";s:28:"profile_use_background_image";b:1;s:15:"default_profile";b:1;s:21:"default_profile_image";b:0;s:9:"following";b:0;s:19:"follow_request_sent";b:0;s:13:"notifications";b:0;}s:3:"geo";N;s:11:"coordinates";N;s:5:"place";N;s:12:"contributors";N;s:13:"retweet_count";i:0;s:14:"favorite_count";i:1;s:8:"entities";a:4:{s:8:"hashtags";a:0:{}s:7:"symbols";a:0:{}s:4:"urls";a:1:{i:0;a:4:{s:3:"url";s:22:"http://t.co/0twsFu9qsC";s:12:"expanded_url";s:34:"http://instagram.com/p/kOgdiiwMKa/";s:11:"display_url";s:27:"instagram.com/p/kOgdiiwMKa/";s:7:"indices";a:2:{i:0;i:99;i:1;i:121;}}}s:13:"user_mentions";a:0:{}}s:9:"favorited";b:0;s:9:"retweeted";b:0;s:18:"possibly_sensitive";b:0;s:4:"lang";s:2:"en";}i:10;a:23:{s:10:"created_at";s:30:"Sun Feb 09 01:59:43 +0000 2014";s:2:"id";i:432332954606784512;s:6:"id_str";s:18:"432332954606784512";s:4:"text";s:44:"Jack\'s first hair cut http://t.co/8Nh22OSdkY";s:6:"source";s:59:"<a href="http://instagram.com" rel="nofollow">Instagram</a>";s:9:"truncated";b:0;s:21:"in_reply_to_status_id";N;s:25:"in_reply_to_status_id_str";N;s:19:"in_reply_to_user_id";N;s:23:"in_reply_to_user_id_str";N;s:23:"in_reply_to_screen_name";N;s:4:"user";a:39:{s:2:"id";i:35583247;s:6:"id_str";s:8:"35583247";s:4:"name";s:15:"Sarah Tomlinson";s:11:"screen_name";s:13:"duchessofrock";s:8:"location";s:13:"LA / Brooklyn";s:11:"description";s:67:"I feel the same way about writing that you felt about Breaking Bad.";s:3:"url";s:22:"http://t.co/NoNeYVwP4x";s:8:"entities";a:2:{s:3:"url";a:1:{s:4:"urls";a:1:{i:0;a:4:{s:3:"url";s:22:"http://t.co/NoNeYVwP4x";s:12:"expanded_url";s:30:"http://sarahtomlinson:8888.com";s:11:"display_url";s:18:"sarahtomlinson.com";s:7:"indices";a:2:{i:0;i:0;i:1;i:22;}}}}s:11:"description";a:1:{s:4:"urls";a:0:{}}}s:9:"protected";b:0;s:15:"followers_count";i:314;s:13:"friends_count";i:161;s:12:"listed_count";i:8;s:10:"created_at";s:30:"Sun Apr 26 22:23:48 +0000 2009";s:16:"favourites_count";i:30;s:10:"utc_offset";i:-28800;s:9:"time_zone";s:26:"Pacific Time (US & Canada)";s:11:"geo_enabled";b:0;s:8:"verified";b:0;s:14:"statuses_count";i:256;s:4:"lang";s:2:"en";s:20:"contributors_enabled";b:0;s:13:"is_translator";b:0;s:22:"is_translation_enabled";b:0;s:24:"profile_background_color";s:6:"C0DEED";s:28:"profile_background_image_url";s:48:"http://abs.twimg.com/images/themes/theme1/bg.png";s:34:"profile_background_image_url_https";s:49:"https://abs.twimg.com/images/themes/theme1/bg.png";s:23:"profile_background_tile";b:0;s:17:"profile_image_url";s:84:"http://pbs.twimg.com/profile_images/239465319/SarahTomlinsonLZ1T3809_copy_normal.jpg";s:23:"profile_image_url_https";s:85:"https://pbs.twimg.com/profile_images/239465319/SarahTomlinsonLZ1T3809_copy_normal.jpg";s:18:"profile_link_color";s:6:"0084B4";s:28:"profile_sidebar_border_color";s:6:"C0DEED";s:26:"profile_sidebar_fill_color";s:6:"DDEEF6";s:18:"profile_text_color";s:6:"333333";s:28:"profile_use_background_image";b:1;s:15:"default_profile";b:1;s:21:"default_profile_image";b:0;s:9:"following";b:0;s:19:"follow_request_sent";b:0;s:13:"notifications";b:0;}s:3:"geo";N;s:11:"coordinates";N;s:5:"place";N;s:12:"contributors";N;s:13:"retweet_count";i:0;s:14:"favorite_count";i:0;s:8:"entities";a:4:{s:8:"hashtags";a:0:{}s:7:"symbols";a:0:{}s:4:"urls";a:1:{i:0;a:4:{s:3:"url";s:22:"http://t.co/8Nh22OSdkY";s:12:"expanded_url";s:34:"http://instagram.com/p/kLYIWZwMFU/";s:11:"display_url";s:27:"instagram.com/p/kLYIWZwMFU/";s:7:"indices";a:2:{i:0;i:22;i:1;i:44;}}}s:13:"user_mentions";a:0:{}}s:9:"favorited";b:0;s:9:"retweeted";b:0;s:18:"possibly_sensitive";b:0;s:4:"lang";s:2:"en";}i:11;a:23:{s:10:"created_at";s:30:"Fri Feb 07 08:08:01 +0000 2014";s:2:"id";i:431700863912923136;s:6:"id_str";s:18:"431700863912923136";s:4:"text";s:117:"The lovely Liela + the son of my mom\'s favorite Beatle on keys. Love this Roman Remains record http://t.co/laXLWbsLYe";s:6:"source";s:59:"<a href="http://instagram.com" rel="nofollow">Instagram</a>";s:9:"truncated";b:0;s:21:"in_reply_to_status_id";N;s:25:"in_reply_to_status_id_str";N;s:19:"in_reply_to_user_id";N;s:23:"in_reply_to_user_id_str";N;s:23:"in_reply_to_screen_name";N;s:4:"user";a:39:{s:2:"id";i:35583247;s:6:"id_str";s:8:"35583247";s:4:"name";s:15:"Sarah Tomlinson";s:11:"screen_name";s:13:"duchessofrock";s:8:"location";s:13:"LA / Brooklyn";s:11:"description";s:67:"I feel the same way about writing that you felt about Breaking Bad.";s:3:"url";s:22:"http://t.co/NoNeYVwP4x";s:8:"entities";a:2:{s:3:"url";a:1:{s:4:"urls";a:1:{i:0;a:4:{s:3:"url";s:22:"http://t.co/NoNeYVwP4x";s:12:"expanded_url";s:30:"http://sarahtomlinson:8888.com";s:11:"display_url";s:18:"sarahtomlinson.com";s:7:"indices";a:2:{i:0;i:0;i:1;i:22;}}}}s:11:"description";a:1:{s:4:"urls";a:0:{}}}s:9:"protected";b:0;s:15:"followers_count";i:314;s:13:"friends_count";i:161;s:12:"listed_count";i:8;s:10:"created_at";s:30:"Sun Apr 26 22:23:48 +0000 2009";s:16:"favourites_count";i:30;s:10:"utc_offset";i:-28800;s:9:"time_zone";s:26:"Pacific Time (US & Canada)";s:11:"geo_enabled";b:0;s:8:"verified";b:0;s:14:"statuses_count";i:256;s:4:"lang";s:2:"en";s:20:"contributors_enabled";b:0;s:13:"is_translator";b:0;s:22:"is_translation_enabled";b:0;s:24:"profile_background_color";s:6:"C0DEED";s:28:"profile_background_image_url";s:48:"http://abs.twimg.com/images/themes/theme1/bg.png";s:34:"profile_background_image_url_https";s:49:"https://abs.twimg.com/images/themes/theme1/bg.png";s:23:"profile_background_tile";b:0;s:17:"profile_image_url";s:84:"http://pbs.twimg.com/profile_images/239465319/SarahTomlinsonLZ1T3809_copy_normal.jpg";s:23:"profile_image_url_https";s:85:"https://pbs.twimg.com/profile_images/239465319/SarahTomlinsonLZ1T3809_copy_normal.jpg";s:18:"profile_link_color";s:6:"0084B4";s:28:"profile_sidebar_border_color";s:6:"C0DEED";s:26:"profile_sidebar_fill_color";s:6:"DDEEF6";s:18:"profile_text_color";s:6:"333333";s:28:"profile_use_background_image";b:1;s:15:"default_profile";b:1;s:21:"default_profile_image";b:0;s:9:"following";b:0;s:19:"follow_request_sent";b:0;s:13:"notifications";b:0;}s:3:"geo";N;s:11:"coordinates";N;s:5:"place";N;s:12:"contributors";N;s:13:"retweet_count";i:0;s:14:"favorite_count";i:0;s:8:"entities";a:4:{s:8:"hashtags";a:0:{}s:7:"symbols";a:0:{}s:4:"urls";a:1:{i:0;a:4:{s:3:"url";s:22:"http://t.co/laXLWbsLYe";s:12:"expanded_url";s:34:"http://instagram.com/p/kG4sFQwML_/";s:11:"display_url";s:27:"instagram.com/p/kG4sFQwML_/";s:7:"indices";a:2:{i:0;i:95;i:1;i:117;}}}s:13:"user_mentions";a:0:{}}s:9:"favorited";b:0;s:9:"retweeted";b:0;s:18:"possibly_sensitive";b:0;s:4:"lang";s:2:"en";}i:12;a:23:{s:10:"created_at";s:30:"Thu Feb 06 21:51:41 +0000 2014";s:2:"id";i:431545759314366464;s:6:"id_str";s:18:"431545759314366464";s:4:"text";s:70:"Indeed, Elvis. Everyday, I too, write the book: http://t.co/NzSw5EUIkS";s:6:"source";s:3:"web";s:9:"truncated";b:0;s:21:"in_reply_to_status_id";N;s:25:"in_reply_to_status_id_str";N;s:19:"in_reply_to_user_id";N;s:23:"in_reply_to_user_id_str";N;s:23:"in_reply_to_screen_name";N;s:4:"user";a:39:{s:2:"id";i:35583247;s:6:"id_str";s:8:"35583247";s:4:"name";s:15:"Sarah Tomlinson";s:11:"screen_name";s:13:"duchessofrock";s:8:"location";s:13:"LA / Brooklyn";s:11:"description";s:67:"I feel the same way about writing that you felt about Breaking Bad.";s:3:"url";s:22:"http://t.co/NoNeYVwP4x";s:8:"entities";a:2:{s:3:"url";a:1:{s:4:"urls";a:1:{i:0;a:4:{s:3:"url";s:22:"http://t.co/NoNeYVwP4x";s:12:"expanded_url";s:30:"http://sarahtomlinson:8888.com";s:11:"display_url";s:18:"sarahtomlinson.com";s:7:"indices";a:2:{i:0;i:0;i:1;i:22;}}}}s:11:"description";a:1:{s:4:"urls";a:0:{}}}s:9:"protected";b:0;s:15:"followers_count";i:314;s:13:"friends_count";i:161;s:12:"listed_count";i:8;s:10:"created_at";s:30:"Sun Apr 26 22:23:48 +0000 2009";s:16:"favourites_count";i:30;s:10:"utc_offset";i:-28800;s:9:"time_zone";s:26:"Pacific Time (US & Canada)";s:11:"geo_enabled";b:0;s:8:"verified";b:0;s:14:"statuses_count";i:256;s:4:"lang";s:2:"en";s:20:"contributors_enabled";b:0;s:13:"is_translator";b:0;s:22:"is_translation_enabled";b:0;s:24:"profile_background_color";s:6:"C0DEED";s:28:"profile_background_image_url";s:48:"http://abs.twimg.com/images/themes/theme1/bg.png";s:34:"profile_background_image_url_https";s:49:"https://abs.twimg.com/images/themes/theme1/bg.png";s:23:"profile_background_tile";b:0;s:17:"profile_image_url";s:84:"http://pbs.twimg.com/profile_images/239465319/SarahTomlinsonLZ1T3809_copy_normal.jpg";s:23:"profile_image_url_https";s:85:"https://pbs.twimg.com/profile_images/239465319/SarahTomlinsonLZ1T3809_copy_normal.jpg";s:18:"profile_link_color";s:6:"0084B4";s:28:"profile_sidebar_border_color";s:6:"C0DEED";s:26:"profile_sidebar_fill_color";s:6:"DDEEF6";s:18:"profile_text_color";s:6:"333333";s:28:"profile_use_background_image";b:1;s:15:"default_profile";b:1;s:21:"default_profile_image";b:0;s:9:"following";b:0;s:19:"follow_request_sent";b:0;s:13:"notifications";b:0;}s:3:"geo";N;s:11:"coordinates";N;s:5:"place";N;s:12:"contributors";N;s:13:"retweet_count";i:0;s:14:"favorite_count";i:0;s:8:"entities";a:4:{s:8:"hashtags";a:0:{}s:7:"symbols";a:0:{}s:4:"urls";a:1:{i:0;a:4:{s:3:"url";s:22:"http://t.co/NzSw5EUIkS";s:12:"expanded_url";s:53:"http://www.youtube.com/watch?v=lhLztdvgpFY&feature=kp";s:11:"display_url";s:29:"youtube.com/watch?v=lhLztd…";s:7:"indices";a:2:{i:0;i:48;i:1;i:70;}}}s:13:"user_mentions";a:0:{}}s:9:"favorited";b:0;s:9:"retweeted";b:0;s:18:"possibly_sensitive";b:0;s:4:"lang";s:2:"en";}i:13;a:22:{s:10:"created_at";s:30:"Fri Jan 31 21:58:13 +0000 2014";s:2:"id";i:429373076686393344;s:6:"id_str";s:18:"429373076686393344";s:4:"text";s:119:"Friends, give me the strength to recycle these old New Yorkers I never finished reading instead of moving them with me.";s:6:"source";s:3:"web";s:9:"truncated";b:0;s:21:"in_reply_to_status_id";N;s:25:"in_reply_to_status_id_str";N;s:19:"in_reply_to_user_id";N;s:23:"in_reply_to_user_id_str";N;s:23:"in_reply_to_screen_name";N;s:4:"user";a:39:{s:2:"id";i:35583247;s:6:"id_str";s:8:"35583247";s:4:"name";s:15:"Sarah Tomlinson";s:11:"screen_name";s:13:"duchessofrock";s:8:"location";s:13:"LA / Brooklyn";s:11:"description";s:67:"I feel the same way about writing that you felt about Breaking Bad.";s:3:"url";s:22:"http://t.co/NoNeYVwP4x";s:8:"entities";a:2:{s:3:"url";a:1:{s:4:"urls";a:1:{i:0;a:4:{s:3:"url";s:22:"http://t.co/NoNeYVwP4x";s:12:"expanded_url";s:30:"http://sarahtomlinson:8888.com";s:11:"display_url";s:18:"sarahtomlinson.com";s:7:"indices";a:2:{i:0;i:0;i:1;i:22;}}}}s:11:"description";a:1:{s:4:"urls";a:0:{}}}s:9:"protected";b:0;s:15:"followers_count";i:314;s:13:"friends_count";i:161;s:12:"listed_count";i:8;s:10:"created_at";s:30:"Sun Apr 26 22:23:48 +0000 2009";s:16:"favourites_count";i:30;s:10:"utc_offset";i:-28800;s:9:"time_zone";s:26:"Pacific Time (US & Canada)";s:11:"geo_enabled";b:0;s:8:"verified";b:0;s:14:"statuses_count";i:256;s:4:"lang";s:2:"en";s:20:"contributors_enabled";b:0;s:13:"is_translator";b:0;s:22:"is_translation_enabled";b:0;s:24:"profile_background_color";s:6:"C0DEED";s:28:"profile_background_image_url";s:48:"http://abs.twimg.com/images/themes/theme1/bg.png";s:34:"profile_background_image_url_https";s:49:"https://abs.twimg.com/images/themes/theme1/bg.png";s:23:"profile_background_tile";b:0;s:17:"profile_image_url";s:84:"http://pbs.twimg.com/profile_images/239465319/SarahTomlinsonLZ1T3809_copy_normal.jpg";s:23:"profile_image_url_https";s:85:"https://pbs.twimg.com/profile_images/239465319/SarahTomlinsonLZ1T3809_copy_normal.jpg";s:18:"profile_link_color";s:6:"0084B4";s:28:"profile_sidebar_border_color";s:6:"C0DEED";s:26:"profile_sidebar_fill_color";s:6:"DDEEF6";s:18:"profile_text_color";s:6:"333333";s:28:"profile_use_background_image";b:1;s:15:"default_profile";b:1;s:21:"default_profile_image";b:0;s:9:"following";b:0;s:19:"follow_request_sent";b:0;s:13:"notifications";b:0;}s:3:"geo";N;s:11:"coordinates";N;s:5:"place";N;s:12:"contributors";N;s:13:"retweet_count";i:0;s:14:"favorite_count";i:2;s:8:"entities";a:4:{s:8:"hashtags";a:0:{}s:7:"symbols";a:0:{}s:4:"urls";a:0:{}s:13:"user_mentions";a:0:{}}s:9:"favorited";b:0;s:9:"retweeted";b:0;s:4:"lang";s:2:"en";}i:14;a:22:{s:10:"created_at";s:30:"Mon Jan 27 00:12:36 +0000 2014";s:2:"id";i:427594956052500480;s:6:"id_str";s:18:"427594956052500480";s:4:"text";s:120:"I prefer my epiphanies with just enough profanity to keep it real. Thank you @TheDailyLove for an epic event last night!";s:6:"source";s:3:"web";s:9:"truncated";b:0;s:21:"in_reply_to_status_id";N;s:25:"in_reply_to_status_id_str";N;s:19:"in_reply_to_user_id";N;s:23:"in_reply_to_user_id_str";N;s:23:"in_reply_to_screen_name";N;s:4:"user";a:39:{s:2:"id";i:35583247;s:6:"id_str";s:8:"35583247";s:4:"name";s:15:"Sarah Tomlinson";s:11:"screen_name";s:13:"duchessofrock";s:8:"location";s:13:"LA / Brooklyn";s:11:"description";s:67:"I feel the same way about writing that you felt about Breaking Bad.";s:3:"url";s:22:"http://t.co/NoNeYVwP4x";s:8:"entities";a:2:{s:3:"url";a:1:{s:4:"urls";a:1:{i:0;a:4:{s:3:"url";s:22:"http://t.co/NoNeYVwP4x";s:12:"expanded_url";s:30:"http://sarahtomlinson:8888.com";s:11:"display_url";s:18:"sarahtomlinson.com";s:7:"indices";a:2:{i:0;i:0;i:1;i:22;}}}}s:11:"description";a:1:{s:4:"urls";a:0:{}}}s:9:"protected";b:0;s:15:"followers_count";i:314;s:13:"friends_count";i:161;s:12:"listed_count";i:8;s:10:"created_at";s:30:"Sun Apr 26 22:23:48 +0000 2009";s:16:"favourites_count";i:30;s:10:"utc_offset";i:-28800;s:9:"time_zone";s:26:"Pacific Time (US & Canada)";s:11:"geo_enabled";b:0;s:8:"verified";b:0;s:14:"statuses_count";i:256;s:4:"lang";s:2:"en";s:20:"contributors_enabled";b:0;s:13:"is_translator";b:0;s:22:"is_translation_enabled";b:0;s:24:"profile_background_color";s:6:"C0DEED";s:28:"profile_background_image_url";s:48:"http://abs.twimg.com/images/themes/theme1/bg.png";s:34:"profile_background_image_url_https";s:49:"https://abs.twimg.com/images/themes/theme1/bg.png";s:23:"profile_background_tile";b:0;s:17:"profile_image_url";s:84:"http://pbs.twimg.com/profile_images/239465319/SarahTomlinsonLZ1T3809_copy_normal.jpg";s:23:"profile_image_url_https";s:85:"https://pbs.twimg.com/profile_images/239465319/SarahTomlinsonLZ1T3809_copy_normal.jpg";s:18:"profile_link_color";s:6:"0084B4";s:28:"profile_sidebar_border_color";s:6:"C0DEED";s:26:"profile_sidebar_fill_color";s:6:"DDEEF6";s:18:"profile_text_color";s:6:"333333";s:28:"profile_use_background_image";b:1;s:15:"default_profile";b:1;s:21:"default_profile_image";b:0;s:9:"following";b:0;s:19:"follow_request_sent";b:0;s:13:"notifications";b:0;}s:3:"geo";N;s:11:"coordinates";N;s:5:"place";N;s:12:"contributors";N;s:13:"retweet_count";i:0;s:14:"favorite_count";i:0;s:8:"entities";a:4:{s:8:"hashtags";a:0:{}s:7:"symbols";a:0:{}s:4:"urls";a:0:{}s:13:"user_mentions";a:1:{i:0;a:5:{s:11:"screen_name";s:12:"TheDailyLove";s:4:"name";s:11:"Mastin Kipp";s:2:"id";i:16870682;s:6:"id_str";s:8:"16870682";s:7:"indices";a:2:{i:0;i:77;i:1;i:90;}}}}s:9:"favorited";b:0;s:9:"retweeted";b:0;s:4:"lang";s:2:"en";}i:15;a:23:{s:10:"created_at";s:30:"Thu Jan 23 21:14:11 +0000 2014";s:2:"id";i:426462891802247169;s:6:"id_str";s:18:"426462891802247169";s:4:"text";s:139:"Loved that my story, The Last Soup of Allen Ginsberg, caused the Allen Ginsberg Project to check the soup: it\'s safe http://t.co/NW3eNDj7vo";s:6:"source";s:3:"web";s:9:"truncated";b:0;s:21:"in_reply_to_status_id";N;s:25:"in_reply_to_status_id_str";N;s:19:"in_reply_to_user_id";N;s:23:"in_reply_to_user_id_str";N;s:23:"in_reply_to_screen_name";N;s:4:"user";a:39:{s:2:"id";i:35583247;s:6:"id_str";s:8:"35583247";s:4:"name";s:15:"Sarah Tomlinson";s:11:"screen_name";s:13:"duchessofrock";s:8:"location";s:13:"LA / Brooklyn";s:11:"description";s:67:"I feel the same way about writing that you felt about Breaking Bad.";s:3:"url";s:22:"http://t.co/NoNeYVwP4x";s:8:"entities";a:2:{s:3:"url";a:1:{s:4:"urls";a:1:{i:0;a:4:{s:3:"url";s:22:"http://t.co/NoNeYVwP4x";s:12:"expanded_url";s:30:"http://sarahtomlinson:8888.com";s:11:"display_url";s:18:"sarahtomlinson.com";s:7:"indices";a:2:{i:0;i:0;i:1;i:22;}}}}s:11:"description";a:1:{s:4:"urls";a:0:{}}}s:9:"protected";b:0;s:15:"followers_count";i:314;s:13:"friends_count";i:161;s:12:"listed_count";i:8;s:10:"created_at";s:30:"Sun Apr 26 22:23:48 +0000 2009";s:16:"favourites_count";i:30;s:10:"utc_offset";i:-28800;s:9:"time_zone";s:26:"Pacific Time (US & Canada)";s:11:"geo_enabled";b:0;s:8:"verified";b:0;s:14:"statuses_count";i:256;s:4:"lang";s:2:"en";s:20:"contributors_enabled";b:0;s:13:"is_translator";b:0;s:22:"is_translation_enabled";b:0;s:24:"profile_background_color";s:6:"C0DEED";s:28:"profile_background_image_url";s:48:"http://abs.twimg.com/images/themes/theme1/bg.png";s:34:"profile_background_image_url_https";s:49:"https://abs.twimg.com/images/themes/theme1/bg.png";s:23:"profile_background_tile";b:0;s:17:"profile_image_url";s:84:"http://pbs.twimg.com/profile_images/239465319/SarahTomlinsonLZ1T3809_copy_normal.jpg";s:23:"profile_image_url_https";s:85:"https://pbs.twimg.com/profile_images/239465319/SarahTomlinsonLZ1T3809_copy_normal.jpg";s:18:"profile_link_color";s:6:"0084B4";s:28:"profile_sidebar_border_color";s:6:"C0DEED";s:26:"profile_sidebar_fill_color";s:6:"DDEEF6";s:18:"profile_text_color";s:6:"333333";s:28:"profile_use_background_image";b:1;s:15:"default_profile";b:1;s:21:"default_profile_image";b:0;s:9:"following";b:0;s:19:"follow_request_sent";b:0;s:13:"notifications";b:0;}s:3:"geo";N;s:11:"coordinates";N;s:5:"place";N;s:12:"contributors";N;s:13:"retweet_count";i:1;s:14:"favorite_count";i:0;s:8:"entities";a:4:{s:8:"hashtags";a:0:{}s:7:"symbols";a:0:{}s:4:"urls";a:1:{i:0;a:4:{s:3:"url";s:22:"http://t.co/NW3eNDj7vo";s:12:"expanded_url";s:56:"http://ginsbergblog.blogspot.com/2013_12_01_archive.html";s:11:"display_url";s:43:"ginsbergblog.blogspot.com/2013_12_01_arc…";s:7:"indices";a:2:{i:0;i:117;i:1;i:139;}}}s:13:"user_mentions";a:0:{}}s:9:"favorited";b:0;s:9:"retweeted";b:0;s:18:"possibly_sensitive";b:0;s:4:"lang";s:2:"en";}i:16;a:23:{s:10:"created_at";s:30:"Wed Jan 22 18:42:41 +0000 2014";s:2:"id";i:426062379277770752;s:6:"id_str";s:18:"426062379277770752";s:4:"text";s:61:"Oh, Patti, I love you so. PURE MAGIC:  http://t.co/BP28wIxsK0";s:6:"source";s:3:"web";s:9:"truncated";b:0;s:21:"in_reply_to_status_id";N;s:25:"in_reply_to_status_id_str";N;s:19:"in_reply_to_user_id";N;s:23:"in_reply_to_user_id_str";N;s:23:"in_reply_to_screen_name";N;s:4:"user";a:39:{s:2:"id";i:35583247;s:6:"id_str";s:8:"35583247";s:4:"name";s:15:"Sarah Tomlinson";s:11:"screen_name";s:13:"duchessofrock";s:8:"location";s:13:"LA / Brooklyn";s:11:"description";s:67:"I feel the same way about writing that you felt about Breaking Bad.";s:3:"url";s:22:"http://t.co/NoNeYVwP4x";s:8:"entities";a:2:{s:3:"url";a:1:{s:4:"urls";a:1:{i:0;a:4:{s:3:"url";s:22:"http://t.co/NoNeYVwP4x";s:12:"expanded_url";s:30:"http://sarahtomlinson:8888.com";s:11:"display_url";s:18:"sarahtomlinson.com";s:7:"indices";a:2:{i:0;i:0;i:1;i:22;}}}}s:11:"description";a:1:{s:4:"urls";a:0:{}}}s:9:"protected";b:0;s:15:"followers_count";i:314;s:13:"friends_count";i:161;s:12:"listed_count";i:8;s:10:"created_at";s:30:"Sun Apr 26 22:23:48 +0000 2009";s:16:"favourites_count";i:30;s:10:"utc_offset";i:-28800;s:9:"time_zone";s:26:"Pacific Time (US & Canada)";s:11:"geo_enabled";b:0;s:8:"verified";b:0;s:14:"statuses_count";i:256;s:4:"lang";s:2:"en";s:20:"contributors_enabled";b:0;s:13:"is_translator";b:0;s:22:"is_translation_enabled";b:0;s:24:"profile_background_color";s:6:"C0DEED";s:28:"profile_background_image_url";s:48:"http://abs.twimg.com/images/themes/theme1/bg.png";s:34:"profile_background_image_url_https";s:49:"https://abs.twimg.com/images/themes/theme1/bg.png";s:23:"profile_background_tile";b:0;s:17:"profile_image_url";s:84:"http://pbs.twimg.com/profile_images/239465319/SarahTomlinsonLZ1T3809_copy_normal.jpg";s:23:"profile_image_url_https";s:85:"https://pbs.twimg.com/profile_images/239465319/SarahTomlinsonLZ1T3809_copy_normal.jpg";s:18:"profile_link_color";s:6:"0084B4";s:28:"profile_sidebar_border_color";s:6:"C0DEED";s:26:"profile_sidebar_fill_color";s:6:"DDEEF6";s:18:"profile_text_color";s:6:"333333";s:28:"profile_use_background_image";b:1;s:15:"default_profile";b:1;s:21:"default_profile_image";b:0;s:9:"following";b:0;s:19:"follow_request_sent";b:0;s:13:"notifications";b:0;}s:3:"geo";N;s:11:"coordinates";N;s:5:"place";N;s:12:"contributors";N;s:13:"retweet_count";i:0;s:14:"favorite_count";i:0;s:8:"entities";a:4:{s:8:"hashtags";a:0:{}s:7:"symbols";a:0:{}s:4:"urls";a:1:{i:0;a:4:{s:3:"url";s:22:"http://t.co/BP28wIxsK0";s:12:"expanded_url";s:95:"http://jezebel.com/patti-smith-says-her-favorite-song-of-2013-was-rihanna-1506303280?autoplay=1";s:11:"display_url";s:29:"jezebel.com/patti-smith-sa…";s:7:"indices";a:2:{i:0;i:39;i:1;i:61;}}}s:13:"user_mentions";a:0:{}}s:9:"favorited";b:0;s:9:"retweeted";b:0;s:18:"possibly_sensitive";b:0;s:4:"lang";s:2:"en";}i:17;a:23:{s:10:"created_at";s:30:"Wed Jan 15 20:58:07 +0000 2014";s:2:"id";i:423559744964403201;s:6:"id_str";s:18:"423559744964403201";s:4:"text";s:136:""I\'m the pearl" Love it! RT @steffienelson I chatted with Willow Smith for @vmagazine; @KarlLagerfeld photos: http://t.co/otxrxoOg8y …";s:6:"source";s:3:"web";s:9:"truncated";b:0;s:21:"in_reply_to_status_id";N;s:25:"in_reply_to_status_id_str";N;s:19:"in_reply_to_user_id";N;s:23:"in_reply_to_user_id_str";N;s:23:"in_reply_to_screen_name";N;s:4:"user";a:39:{s:2:"id";i:35583247;s:6:"id_str";s:8:"35583247";s:4:"name";s:15:"Sarah Tomlinson";s:11:"screen_name";s:13:"duchessofrock";s:8:"location";s:13:"LA / Brooklyn";s:11:"description";s:67:"I feel the same way about writing that you felt about Breaking Bad.";s:3:"url";s:22:"http://t.co/NoNeYVwP4x";s:8:"entities";a:2:{s:3:"url";a:1:{s:4:"urls";a:1:{i:0;a:4:{s:3:"url";s:22:"http://t.co/NoNeYVwP4x";s:12:"expanded_url";s:30:"http://sarahtomlinson:8888.com";s:11:"display_url";s:18:"sarahtomlinson.com";s:7:"indices";a:2:{i:0;i:0;i:1;i:22;}}}}s:11:"description";a:1:{s:4:"urls";a:0:{}}}s:9:"protected";b:0;s:15:"followers_count";i:314;s:13:"friends_count";i:161;s:12:"listed_count";i:8;s:10:"created_at";s:30:"Sun Apr 26 22:23:48 +0000 2009";s:16:"favourites_count";i:30;s:10:"utc_offset";i:-28800;s:9:"time_zone";s:26:"Pacific Time (US & Canada)";s:11:"geo_enabled";b:0;s:8:"verified";b:0;s:14:"statuses_count";i:256;s:4:"lang";s:2:"en";s:20:"contributors_enabled";b:0;s:13:"is_translator";b:0;s:22:"is_translation_enabled";b:0;s:24:"profile_background_color";s:6:"C0DEED";s:28:"profile_background_image_url";s:48:"http://abs.twimg.com/images/themes/theme1/bg.png";s:34:"profile_background_image_url_https";s:49:"https://abs.twimg.com/images/themes/theme1/bg.png";s:23:"profile_background_tile";b:0;s:17:"profile_image_url";s:84:"http://pbs.twimg.com/profile_images/239465319/SarahTomlinsonLZ1T3809_copy_normal.jpg";s:23:"profile_image_url_https";s:85:"https://pbs.twimg.com/profile_images/239465319/SarahTomlinsonLZ1T3809_copy_normal.jpg";s:18:"profile_link_color";s:6:"0084B4";s:28:"profile_sidebar_border_color";s:6:"C0DEED";s:26:"profile_sidebar_fill_color";s:6:"DDEEF6";s:18:"profile_text_color";s:6:"333333";s:28:"profile_use_background_image";b:1;s:15:"default_profile";b:1;s:21:"default_profile_image";b:0;s:9:"following";b:0;s:19:"follow_request_sent";b:0;s:13:"notifications";b:0;}s:3:"geo";N;s:11:"coordinates";N;s:5:"place";N;s:12:"contributors";N;s:13:"retweet_count";i:1;s:14:"favorite_count";i:0;s:8:"entities";a:4:{s:8:"hashtags";a:0:{}s:7:"symbols";a:0:{}s:4:"urls";a:1:{i:0;a:4:{s:3:"url";s:22:"http://t.co/otxrxoOg8y";s:12:"expanded_url";s:72:"http://www.vmagazine.com/site/content/2053/the-world-according-to-willow";s:11:"display_url";s:31:"vmagazine.com/site/content/2…";s:7:"indices";a:2:{i:0;i:110;i:1;i:132;}}}s:13:"user_mentions";a:3:{i:0;a:5:{s:11:"screen_name";s:13:"steffienelson";s:4:"name";s:14:"Steffie Nelson";s:2:"id";i:2204252460;s:6:"id_str";s:10:"2204252460";s:7:"indices";a:2:{i:0;i:28;i:1;i:42;}}i:1;a:5:{s:11:"screen_name";s:9:"vmagazine";s:4:"name";s:10:"V Magazine";s:2:"id";i:25326324;s:6:"id_str";s:8:"25326324";s:7:"indices";a:2:{i:0;i:75;i:1;i:85;}}i:2;a:5:{s:11:"screen_name";s:13:"KarlLagerfeld";s:4:"name";s:14:"Karl Lagerfeld";s:2:"id";i:465723566;s:6:"id_str";s:9:"465723566";s:7:"indices";a:2:{i:0;i:87;i:1;i:101;}}}}s:9:"favorited";b:0;s:9:"retweeted";b:0;s:18:"possibly_sensitive";b:0;s:4:"lang";s:2:"en";}s:10:"httpstatus";i:200;}', 'yes') ;
INSERT INTO `ws_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(516, 'rg_gforms_key', 'e2bcf247a38474845eb506295f57567e', 'yes'),
(517, 'rg_gforms_disable_css', '0', 'yes'),
(518, 'rg_gforms_enable_html5', '0', 'yes'),
(519, 'gform_enable_noconflict', '0', 'yes'),
(520, 'rg_gforms_enable_akismet', '', 'yes'),
(521, 'rg_gforms_captcha_public_key', '', 'yes'),
(522, 'rg_gforms_captcha_private_key', '', 'yes'),
(523, 'rg_gforms_currency', 'USD', 'yes'),
(524, 'rg_gforms_message', '<!--GFM-->', 'yes'),
(753, 'duplicator_package_active', 's:2674:"O:11:"DUP_Package":15:{s:2:"ID";N;s:4:"Name";s:23:"20140226_sarahtomlinson";s:4:"Hash";N;s:8:"NameHash";N;s:7:"Version";s:5:"0.5.2";s:4:"Type";i:0;s:5:"Notes";s:0:"";s:9:"StorePath";s:75:"/Volumes/Donnie/Dropbox/2014 Projects/Sarah Tomlinson/SIte/wp-snapshots/tmp";s:8:"StoreURL";s:40:"http://sarahtomlinson:8888/wp-snapshots/";s:7:"Runtime";N;s:7:"ExeSize";N;s:7:"ZipSize";N;s:7:"Archive";O:11:"DUP_Archive":15:{s:10:"FilterDirs";s:0:"";s:10:"FilterExts";s:0:"";s:8:"FilterOn";i:0;s:4:"File";N;s:6:"Format";s:3:"ZIP";s:7:"PackDir";s:58:"/Volumes/Donnie/Dropbox/2014 Projects/Sarah Tomlinson/SIte";s:8:"DirCount";i:0;s:9:"FileCount";i:0;s:9:"LinkCount";i:0;s:4:"Size";i:0;s:11:"BigFileList";a:0:{}s:15:"InvalidFileList";a:0:{}s:10:"\0*\0Package";O:11:"DUP_Package":15:{s:2:"ID";N;s:4:"Name";s:23:"20140226_sarahtomlinson";s:4:"Hash";N;s:8:"NameHash";N;s:7:"Version";s:5:"0.5.2";s:4:"Type";i:0;s:5:"Notes";s:0:"";s:9:"StorePath";s:75:"/Volumes/Donnie/Dropbox/2014 Projects/Sarah Tomlinson/SIte/wp-snapshots/tmp";s:8:"StoreURL";s:35:"http://sarahtomlinson/wp-snapshots/";s:7:"Runtime";N;s:7:"ExeSize";N;s:7:"ZipSize";N;s:7:"Archive";O:11:"DUP_Archive":15:{s:10:"FilterDirs";s:0:"";s:10:"FilterExts";s:0:"";s:8:"FilterOn";i:0;s:4:"File";N;s:6:"Format";s:3:"ZIP";s:7:"PackDir";s:58:"/Volumes/Donnie/Dropbox/2014 Projects/Sarah Tomlinson/SIte";s:8:"DirCount";i:0;s:9:"FileCount";i:0;s:9:"LinkCount";i:0;s:4:"Size";i:0;s:11:"BigFileList";a:0:{}s:15:"InvalidFileList";a:0:{}s:10:"\0*\0Package";r:27;s:28:"\0DUP_Archive\0filterDirsArray";a:0:{}s:28:"\0DUP_Archive\0filterExtsArray";a:0:{}}s:9:"Installer";O:13:"DUP_Installer":11:{s:4:"File";N;s:4:"Size";i:0;s:10:"OptsDBHost";s:0:"";s:10:"OptsDBName";s:0:"";s:10:"OptsDBUser";s:0:"";s:12:"OptsSSLAdmin";i:0;s:12:"OptsSSLLogin";i:0;s:11:"OptsCacheWP";i:0;s:13:"OptsCachePath";i:0;s:10:"OptsURLNew";s:0:"";s:10:"\0*\0Package";r:27;}s:8:"Database";O:12:"DUP_Database":9:{s:4:"Type";s:5:"MySQL";s:4:"Size";N;s:4:"File";N;s:4:"Path";N;s:12:"FilterTables";s:0:"";s:8:"FilterOn";i:0;s:4:"Name";N;s:10:"\0*\0Package";r:27;s:25:"\0DUP_Database\0dbStorePath";N;}}s:28:"\0DUP_Archive\0filterDirsArray";a:0:{}s:28:"\0DUP_Archive\0filterExtsArray";a:0:{}}s:9:"Installer";O:13:"DUP_Installer":11:{s:4:"File";N;s:4:"Size";i:0;s:10:"OptsDBHost";s:0:"";s:10:"OptsDBName";s:0:"";s:10:"OptsDBUser";s:0:"";s:12:"OptsSSLAdmin";i:0;s:12:"OptsSSLLogin";i:0;s:11:"OptsCacheWP";i:0;s:13:"OptsCachePath";i:0;s:10:"OptsURLNew";s:0:"";s:10:"\0*\0Package";r:27;}s:8:"Database";O:12:"DUP_Database":9:{s:4:"Type";s:5:"MySQL";s:4:"Size";N;s:4:"File";N;s:4:"Path";N;s:12:"FilterTables";s:0:"";s:8:"FilterOn";i:0;s:4:"Name";N;s:10:"\0*\0Package";r:27;s:25:"\0DUP_Database\0dbStorePath";N;}}";', 'yes') ;

#
# End of data contents of table `ws_options`
# --------------------------------------------------------



#
# Delete any existing table `ws_postmeta`
#

DROP TABLE IF EXISTS `ws_postmeta`;


#
# Table structure of table `ws_postmeta`
#

CREATE TABLE `ws_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=148 DEFAULT CHARSET=utf8;


#
# Data contents of table `ws_postmeta`
#
INSERT INTO `ws_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(6, 1, '_edit_last', '1'),
(8, 1, '_edit_lock', '1392026834:1'),
(9, 7, '_edit_last', '1'),
(10, 7, 'field_52faaef23bc43', 'a:14:{s:3:"key";s:19:"field_52faaef23bc43";s:5:"label";s:4:"tesf";s:4:"name";s:4:"tesf";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}'),
(11, 7, 'field_52faaef63bc44', 'a:11:{s:3:"key";s:19:"field_52faaef63bc44";s:5:"label";s:5:"sdsad";s:4:"name";s:5:"sdsad";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:11:"save_format";s:6:"object";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:10:"uploadedTo";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:2:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:1;}'),
(12, 7, 'field_52faaefc3bc45', 'a:13:{s:3:"key";s:19:"field_52faaefc3bc45";s:5:"label";s:9:"dsadsadas";s:4:"name";s:9:"dsadsadas";s:4:"type";s:8:"repeater";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:10:"sub_fields";a:2:{i:0;a:15:{s:3:"key";s:19:"field_52faaf063bc46";s:5:"label";s:6:"dasdas";s:4:"name";s:6:"dasdas";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:12:"column_width";s:0:"";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}i:1;a:15:{s:3:"key";s:19:"field_52faaf093bc47";s:5:"label";s:6:"sadasd";s:4:"name";s:6:"sadasd";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:12:"column_width";s:0:"";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:1;}}s:7:"row_min";s:0:"";s:9:"row_limit";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:7:"Add Row";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:2;}'),
(14, 7, 'position', 'normal'),
(15, 7, 'layout', 'default'),
(16, 7, 'hide_on_screen', ''),
(17, 7, '_edit_lock', '1392161178:1'),
(18, 8, '_wp_attached_file', '2014/02/Adornments.jpg'),
(19, 8, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:949;s:6:"height";i:281;s:4:"file";s:22:"2014/02/Adornments.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"Adornments-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"Adornments-300x88.jpg";s:5:"width";i:300;s:6:"height";i:88;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(20, 2, 'tesf', ''),
(21, 2, '_tesf', 'field_52faaef23bc43'),
(22, 2, 'sdsad', '8'),
(23, 2, '_sdsad', 'field_52faaef63bc44'),
(24, 2, 'dsadsadas_0_dasdas', 'sdasdas'),
(25, 2, '_dsadsadas_0_dasdas', 'field_52faaf063bc46'),
(26, 2, 'dsadsadas_0_sadasd', 'asdsadas'),
(27, 2, '_dsadsadas_0_sadasd', 'field_52faaf093bc47'),
(28, 2, 'dsadsadas_1_dasdas', 'adsada'),
(29, 2, '_dsadsadas_1_dasdas', 'field_52faaf063bc46'),
(30, 2, 'dsadsadas_1_sadasd', 'dasdas'),
(31, 2, '_dsadsadas_1_sadasd', 'field_52faaf093bc47'),
(32, 2, 'dsadsadas', '2'),
(33, 2, '_dsadsadas', 'field_52faaefc3bc45'),
(34, 9, '_wp_attached_file', '2014/02/12095141143_50f0dac4c5_c-1.jpg'),
(35, 9, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:800;s:6:"height";i:534;s:4:"file";s:38:"2014/02/12095141143_50f0dac4c5_c-1.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:38:"12095141143_50f0dac4c5_c-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:38:"12095141143_50f0dac4c5_c-1-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(36, 7, 'rule', 'a:5:{s:5:"param";s:4:"page";s:8:"operator";s:2:"==";s:5:"value";s:1:"2";s:8:"order_no";i:0;s:8:"group_no";i:0;}'),
(37, 2, '_wp_trash_meta_status', 'publish'),
(38, 2, '_wp_trash_meta_time', '1392463483'),
(39, 11, '_edit_last', '1'),
(40, 11, '_wp_page_template', 'default'),
(41, 11, '_edit_lock', '1392464446:1'),
(42, 13, '_menu_item_type', 'post_type'),
(43, 13, '_menu_item_menu_item_parent', '0'),
(44, 13, '_menu_item_object_id', '11'),
(45, 13, '_menu_item_object', 'page'),
(46, 13, '_menu_item_target', ''),
(47, 13, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(48, 13, '_menu_item_xfn', ''),
(49, 13, '_menu_item_url', ''),
(51, 14, '_menu_item_type', 'taxonomy'),
(52, 14, '_menu_item_menu_item_parent', '0'),
(53, 14, '_menu_item_object_id', '2'),
(54, 14, '_menu_item_object', 'category'),
(55, 14, '_menu_item_target', ''),
(56, 14, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(57, 14, '_menu_item_xfn', ''),
(58, 14, '_menu_item_url', ''),
(60, 15, '_menu_item_type', 'taxonomy'),
(61, 15, '_menu_item_menu_item_parent', '0'),
(62, 15, '_menu_item_object_id', '4'),
(63, 15, '_menu_item_object', 'category'),
(64, 15, '_menu_item_target', ''),
(65, 15, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(66, 15, '_menu_item_xfn', ''),
(67, 15, '_menu_item_url', ''),
(69, 16, '_menu_item_type', 'taxonomy'),
(70, 16, '_menu_item_menu_item_parent', '0'),
(71, 16, '_menu_item_object_id', '3'),
(72, 16, '_menu_item_object', 'category'),
(73, 16, '_menu_item_target', ''),
(74, 16, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(75, 16, '_menu_item_xfn', ''),
(76, 16, '_menu_item_url', ''),
(78, 17, '_menu_item_type', 'taxonomy'),
(79, 17, '_menu_item_menu_item_parent', '0'),
(80, 17, '_menu_item_object_id', '5'),
(81, 17, '_menu_item_object', 'category'),
(82, 17, '_menu_item_target', ''),
(83, 17, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(84, 17, '_menu_item_xfn', ''),
(85, 17, '_menu_item_url', ''),
(87, 19, '_edit_last', '1'),
(88, 19, 'field_52ff4f7578492', 'a:11:{s:3:"key";s:19:"field_52ff4f7578492";s:5:"label";s:5:"Image";s:4:"name";s:5:"image";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:11:"save_format";s:6:"object";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}'),
(89, 19, 'field_52ff4f7f78493', 'a:11:{s:3:"key";s:19:"field_52ff4f7f78493";s:5:"label";s:7:"Excerpt";s:4:"name";s:7:"excerpt";s:4:"type";s:7:"wysiwyg";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:7:"toolbar";s:4:"full";s:12:"media_upload";s:3:"yes";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:2:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:1;}'),
(91, 19, 'position', 'normal'),
(92, 19, 'layout', 'default'),
(93, 19, 'hide_on_screen', ''),
(94, 19, '_edit_lock', '1392463849:1'),
(97, 19, 'rule', 'a:5:{s:5:"param";s:4:"page";s:8:"operator";s:2:"==";s:5:"value";s:2:"11";s:8:"order_no";i:0;s:8:"group_no";i:0;}'),
(98, 20, 'image', ''),
(99, 20, '_image', 'field_52ff4f7578492'),
(100, 20, 'excerpt', '<strong>Sarah Tomlinson</strong> is a Los Angeles- and Brooklyn-based writer. Her writing has appeared in publications including Marie Claire, The Los Angeles Times, The Boston Globe, Salon.com and Vol. 1 Brooklyn. She has ghostwritten nine books, including two uncredited NYT-bestsellers.\r\n\r\nHer father-daughter memoir, Good Girl, is forthcoming from Gallery Books (Simon &amp; Schuster) in early 2015. She is happy to visit with book clubs in California, New York and New England, or via Skype.'),
(101, 20, '_excerpt', 'field_52ff4f7f78493'),
(102, 11, 'image', '21'),
(103, 11, '_image', 'field_52ff4f7578492'),
(104, 11, 'excerpt', '<strong>Sarah Tomlinson</strong> is a Los Angeles- and Brooklyn-based writer. Her writing has appeared in publications including Marie Claire, The Los Angeles Times, The Boston Globe, Salon.com and Vol. 1 Brooklyn. She has ghostwritten nine books, including two uncredited NYT-bestsellers.\r\n\r\nHer father-daughter memoir, Good Girl, is forthcoming from Gallery Books (Simon &amp; Schuster) in early 2015. She is happy to visit with book clubs in California, New York and New England, or via Skype.'),
(105, 11, '_excerpt', 'field_52ff4f7f78493'),
(106, 21, '_wp_attached_file', '2014/02/Sidebar-Bio-Pic.png'),
(107, 21, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:220;s:6:"height";i:329;s:4:"file";s:27:"2014/02/Sidebar-Bio-Pic.png";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"Sidebar-Bio-Pic-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:27:"Sidebar-Bio-Pic-200x300.png";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(108, 22, 'image', '21'),
(109, 22, '_image', 'field_52ff4f7578492'),
(110, 22, 'excerpt', '<strong>Sarah Tomlinson</strong> is a Los Angeles- and Brooklyn-based writer. Her writing has appeared in publications including Marie Claire, The Los Angeles Times, The Boston Globe, Salon.com and Vol. 1 Brooklyn. She has ghostwritten nine books, including two uncredited NYT-bestsellers.\r\n\r\nHer father-daughter memoir, Good Girl, is forthcoming from Gallery Books (Simon &amp; Schuster) in early 2015. She is happy to visit with book clubs in California, New York and New England, or via Skype.'),
(111, 22, '_excerpt', 'field_52ff4f7f78493'),
(118, 28, '_edit_last', '1'),
(120, 28, '_edit_lock', '1392464829:1'),
(128, 23, '_edit_last', '1') ;
INSERT INTO `ws_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(130, 23, '_edit_lock', '1392467189:1'),
(131, 43, '_edit_last', '1'),
(132, 43, 'field_52ff53fdbda3e', 'a:14:{s:3:"key";s:19:"field_52ff53fdbda3e";s:5:"label";s:16:"Publication Name";s:4:"name";s:16:"publication_name";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:2:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}'),
(133, 43, 'field_52ff5404bda3f', 'a:14:{s:3:"key";s:19:"field_52ff5404bda3f";s:5:"label";s:3:"URL";s:4:"name";s:3:"url";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:10:"formatting";s:4:"html";s:9:"maxlength";s:0:"";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:2:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:1;}'),
(134, 43, 'rule', 'a:5:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:4:"post";s:8:"order_no";i:0;s:8:"group_no";i:0;}'),
(135, 43, 'position', 'normal'),
(136, 43, 'layout', 'default'),
(137, 43, 'hide_on_screen', ''),
(138, 43, '_edit_lock', '1392464910:1'),
(140, 44, 'publication_name', 'The LA Times'),
(141, 44, '_publication_name', 'field_52ff53fdbda3e'),
(142, 44, 'url', 'http://latimes.com'),
(143, 44, '_url', 'field_52ff5404bda3f'),
(144, 23, 'publication_name', 'The LA Times'),
(145, 23, '_publication_name', 'field_52ff53fdbda3e'),
(146, 23, 'url', 'http://latimes.com'),
(147, 23, '_url', 'field_52ff5404bda3f') ;

#
# End of data contents of table `ws_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `ws_posts`
#

DROP TABLE IF EXISTS `ws_posts`;


#
# Table structure of table `ws_posts`
#

CREATE TABLE `ws_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8;


#
# Data contents of table `ws_posts`
#
INSERT INTO `ws_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2014-02-10 08:31:17', '2014-02-10 08:31:17', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!555', '', 'publish', 'closed', 'closed', '', 'hello-world', '', '', '2014-02-15 11:47:17', '2014-02-15 11:47:17', '', 0, 'http://sarahtomlinson:8888/?p=1', 7, 'post', '', 1),
(2, 1, '2014-02-10 08:31:17', '2014-02-10 08:31:17', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href="http://sarahtomlinson:8888/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'trash', 'open', 'open', '', 'sample-page', '', '', '2014-02-15 11:24:43', '2014-02-15 11:24:43', '', 0, 'http://sarahtomlinson:8888/?page_id=2', 1, 'page', '', 0),
(6, 1, '2014-02-10 10:07:14', '2014-02-10 10:07:14', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!555', '', 'inherit', 'open', 'open', '', '1-revision-v1', '', '', '2014-02-10 10:07:14', '2014-02-10 10:07:14', '', 1, 'http://sarahtomlinson:8888/?p=6', 0, 'revision', '', 0),
(7, 1, '2014-02-11 23:15:39', '2014-02-11 23:15:39', '', 'Frontend Test', '', 'publish', 'closed', 'closed', '', 'acf_frontend-test', '', '', '2014-02-11 23:26:17', '2014-02-11 23:26:17', '', 0, 'http://sarahtomlinson:8888/?post_type=acf&#038;p=7', 0, 'acf', '', 0),
(8, 1, '2014-02-11 23:22:35', '2014-02-11 23:22:35', '', 'Adornments', '', 'inherit', 'open', 'open', '', 'adornments', '', '', '2014-02-11 23:22:35', '2014-02-11 23:22:35', '', 2, 'http://sarahtomlinson:8888/wp-content/uploads/2014/02/Adornments.jpg', 0, 'attachment', 'image/jpeg', 0),
(9, 1, '2014-02-11 23:25:28', '2014-02-11 23:25:28', '', '12095141143_50f0dac4c5_c (1)', '', 'inherit', 'open', 'open', '', '12095141143_50f0dac4c5_c-1', '', '', '2014-02-11 23:25:28', '2014-02-11 23:25:28', '', 0, 'http://sarahtomlinson:8888/wp-content/uploads/2014/02/12095141143_50f0dac4c5_c-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(10, 1, '2014-02-15 11:24:43', '2014-02-15 11:24:43', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href="http://sarahtomlinson:8888/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'inherit', 'open', 'open', '', '2-revision-v1', '', '', '2014-02-15 11:24:43', '2014-02-15 11:24:43', '', 2, 'http://sarahtomlinson:8888/2-revision-v1/', 0, 'revision', '', 0),
(11, 1, '2014-02-15 11:25:20', '2014-02-15 11:25:20', '', 'Bio', '', 'publish', 'closed', 'closed', '', 'bio', '', '', '2014-02-15 11:34:15', '2014-02-15 11:34:15', '', 0, 'http://sarahtomlinson:8888/?page_id=11', 9, 'page', '', 0),
(12, 1, '2014-02-15 11:25:20', '2014-02-15 11:25:20', '', 'Bio', '', 'inherit', 'open', 'open', '', '11-revision-v1', '', '', '2014-02-15 11:25:20', '2014-02-15 11:25:20', '', 11, 'http://sarahtomlinson:8888/11-revision-v1/', 0, 'revision', '', 0),
(13, 1, '2014-02-15 11:26:02', '2014-02-15 11:26:02', ' ', '', '', 'publish', 'open', 'open', '', '13', '', '', '2014-02-15 11:26:02', '2014-02-15 11:26:02', '', 0, 'http://sarahtomlinson:8888/?p=13', 5, 'nav_menu_item', '', 0),
(14, 1, '2014-02-15 11:26:02', '2014-02-15 11:26:02', ' ', '', '', 'publish', 'open', 'open', '', '14', '', '', '2014-02-15 11:26:02', '2014-02-15 11:26:02', '', 0, 'http://sarahtomlinson:8888/?p=14', 1, 'nav_menu_item', '', 0),
(15, 1, '2014-02-15 11:26:02', '2014-02-15 11:26:02', ' ', '', '', 'publish', 'open', 'open', '', '15', '', '', '2014-02-15 11:26:02', '2014-02-15 11:26:02', '', 0, 'http://sarahtomlinson:8888/?p=15', 3, 'nav_menu_item', '', 0),
(16, 1, '2014-02-15 11:26:02', '2014-02-15 11:26:02', ' ', '', '', 'publish', 'open', 'open', '', '16', '', '', '2014-02-15 11:26:02', '2014-02-15 11:26:02', '', 0, 'http://sarahtomlinson:8888/?p=16', 2, 'nav_menu_item', '', 0),
(17, 1, '2014-02-15 11:26:02', '2014-02-15 11:26:02', ' ', '', '', 'publish', 'open', 'open', '', '17', '', '', '2014-02-15 11:26:02', '2014-02-15 11:26:02', '', 0, 'http://sarahtomlinson:8888/?p=17', 4, 'nav_menu_item', '', 0),
(19, 1, '2014-02-15 11:29:18', '2014-02-15 11:29:18', '', 'Homepage Excerpt', '', 'publish', 'closed', 'closed', '', 'acf_homepage-excerpt', '', '', '2014-02-15 11:30:48', '2014-02-15 11:30:48', '', 0, 'http://sarahtomlinson:8888/?post_type=acf&#038;p=19', 0, 'acf', '', 0),
(20, 1, '2014-02-15 11:31:15', '2014-02-15 11:31:15', '', 'Bio', '', 'inherit', 'open', 'open', '', '11-revision-v1', '', '', '2014-02-15 11:31:15', '2014-02-15 11:31:15', '', 11, 'http://sarahtomlinson:8888/11-revision-v1/', 0, 'revision', '', 0),
(21, 1, '2014-02-15 11:34:06', '2014-02-15 11:34:06', '', 'Sidebar-Bio Pic', '', 'inherit', 'open', 'open', '', 'sidebar-bio-pic', '', '', '2014-02-15 11:34:06', '2014-02-15 11:34:06', '', 11, 'http://sarahtomlinson:8888/wp-content/uploads/2014/02/Sidebar-Bio-Pic.png', 0, 'attachment', 'image/png', 0),
(22, 1, '2014-02-15 11:34:15', '2014-02-15 11:34:15', '', 'Bio', '', 'inherit', 'open', 'open', '', '11-revision-v1', '', '', '2014-02-15 11:34:15', '2014-02-15 11:34:15', '', 11, 'http://sarahtomlinson:8888/11-revision-v1/', 0, 'revision', '', 0),
(23, 1, '2014-02-15 11:43:15', '2014-02-15 11:43:15', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Multiple Paragraph Post', '', 'publish', 'closed', 'closed', '', 'multiple-paragraph-post', '', '', '2014-02-15 11:49:11', '2014-02-15 11:49:11', '', 0, 'http://sarahtomlinson:8888/multiple-paragraph-post/', 1, 'post', '', 0),
(24, 1, '2014-02-15 11:43:15', '2014-02-15 11:43:15', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><img src="http://hivemindlabs.com/plugin-data/hive.jpg" width="100%" /><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>', 'Image Post', '', 'publish', 'open', 'open', '', 'image-post', '', '', '2014-02-15 11:47:17', '2014-02-15 11:47:17', '', 0, 'http://sarahtomlinson:8888/image-post/', 2, 'post', '', 0),
(25, 1, '2014-02-15 11:43:15', '2014-02-15 11:43:15', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><ul><li>First Item</li><li>Second Item</li><li>Third Item</li><li>Fourth Item</li><li>Fifth Item</li></ul><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><ol><li>First Item</li><li>Second Item</li><li>Third Item</li><li>Fourth Item</li><li>Fifth Item</li></ol><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>', 'UL and OL Post', '', 'publish', 'open', 'open', '', 'ul-and-ol-post', '', '', '2014-02-15 11:47:17', '2014-02-15 11:47:17', '', 0, 'http://sarahtomlinson:8888/ul-and-ol-post/', 3, 'post', '', 0),
(26, 1, '2014-02-15 11:43:15', '2014-02-15 11:43:15', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><blockquote>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</blockquote><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>', 'Blockquote Post', '', 'publish', 'open', 'open', '', 'blockquote-post', '', '', '2014-02-15 11:47:17', '2014-02-15 11:47:17', '', 0, 'http://sarahtomlinson:8888/blockquote-post/', 4, 'post', '', 0),
(27, 1, '2014-02-15 11:43:15', '2014-02-15 11:43:15', '<p>Lorem ipsum dolor sit amet, <a href="#">consectetur adipisicing</a> elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. <a href="#">Duis aute irure</a> dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia <a href="#">deserunt</a> mollit anim id est laborum.</p>', 'Links Post', '', 'publish', 'open', 'open', '', 'links-post', '', '', '2014-02-15 11:47:17', '2014-02-15 11:47:17', '', 0, 'http://sarahtomlinson:8888/links-post/', 5, 'post', '', 0),
(28, 1, '2014-02-15 11:43:15', '2014-02-15 11:43:15', '<h1>This Is An H1 Tag</h1><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><h2>This Is An H2 Tag</h2><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><h3>This Is An H3 Tag</h3><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><h4>This Is An H4 Tag</h4><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><h5>This Is An H5 Tag</h5><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>', 'Headers Post', '', 'publish', 'closed', 'closed', '', 'headers-post', '', '', '2014-02-15 11:47:17', '2014-02-15 11:47:17', '', 0, 'http://sarahtomlinson:8888/headers-post/', 6, 'post', '', 0),
(29, 1, '2014-02-15 11:43:15', '2014-02-15 11:43:15', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>', 'Multiple Paragraph Page', '', 'publish', 'open', 'open', '', 'multiple-paragraph-page', '', '', '2014-02-15 11:43:15', '2014-02-15 11:43:15', '', 0, 'http://sarahtomlinson:8888/multiple-paragraph-page/', 1, 'page', '', 0),
(30, 1, '2014-02-15 11:43:15', '2014-02-15 11:43:15', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><img src="http://hivemindlabs.com/plugin-data/hive.jpg" width="100%" /><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>', 'Image Page', '', 'publish', 'open', 'open', '', 'image-page', '', '', '2014-02-15 11:43:15', '2014-02-15 11:43:15', '', 0, 'http://sarahtomlinson:8888/image-page/', 2, 'page', '', 0),
(31, 1, '2014-02-15 11:43:15', '2014-02-15 11:43:15', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><ul><li>First Item</li><li>Second Item</li><li>Third Item</li><li>Fourth Item</li><li>Fifth Item</li></ul><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><ol><li>First Item</li><li>Second Item</li><li>Third Item</li><li>Fourth Item</li><li>Fifth Item</li></ol><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>', 'UL and OL Page', '', 'publish', 'open', 'open', '', 'ul-and-ol-page', '', '', '2014-02-15 11:43:15', '2014-02-15 11:43:15', '', 0, 'http://sarahtomlinson:8888/ul-and-ol-page/', 3, 'page', '', 0),
(32, 1, '2014-02-15 11:43:15', '2014-02-15 11:43:15', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><blockquote>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</blockquote><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>', 'Blockquote Page', '', 'publish', 'open', 'open', '', 'blockquote-page', '', '', '2014-02-15 11:43:15', '2014-02-15 11:43:15', '', 0, 'http://sarahtomlinson:8888/blockquote-page/', 4, 'page', '', 0),
(33, 1, '2014-02-15 11:43:15', '2014-02-15 11:43:15', '<p>Lorem ipsum dolor sit amet, <a href="#">consectetur adipisicing</a> elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. <a href="#">Duis aute irure</a> dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia <a href="#">deserunt</a> mollit anim id est laborum.</p>', 'Links Page', '', 'publish', 'open', 'open', '', 'links-page', '', '', '2014-02-15 11:43:15', '2014-02-15 11:43:15', '', 0, 'http://sarahtomlinson:8888/links-page/', 5, 'page', '', 0),
(34, 1, '2014-02-15 11:43:15', '2014-02-15 11:43:15', '<h1>This Is An H1 Tag</h1><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><h2>This Is An H2 Tag</h2><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><h3>This Is An H3 Tag</h3><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><h4>This Is An H4 Tag</h4><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><h5>This Is An H5 Tag</h5><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>', 'Headers Page', '', 'publish', 'open', 'open', '', 'headers-page', '', '', '2014-02-15 11:43:15', '2014-02-15 11:43:15', '', 0, 'http://sarahtomlinson:8888/headers-page/', 6, 'page', '', 0),
(35, 1, '2014-02-15 11:43:15', '2014-02-15 11:43:15', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>', 'Child Page', '', 'publish', 'open', 'open', '', 'child-page', '', '', '2014-02-15 11:43:15', '2014-02-15 11:43:15', '', 30, 'http://sarahtomlinson:8888/image-page/child-page/', 7, 'page', '', 0),
(36, 1, '2014-02-15 11:43:15', '2014-02-15 11:43:15', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>', 'Grandchild Page', '', 'publish', 'open', 'open', '', 'grandchild-page', '', '', '2014-02-15 11:43:15', '2014-02-15 11:43:15', '', 35, 'http://sarahtomlinson:8888/image-page/child-page/grandchild-page/', 8, 'page', '', 0),
(37, 1, '2014-02-15 11:47:09', '2014-02-15 11:47:09', '<h1>This Is An H1 Tag</h1><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><h2>This Is An H2 Tag</h2><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><h3>This Is An H3 Tag</h3><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><h4>This Is An H4 Tag</h4><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><h5>This Is An H5 Tag</h5><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>', 'Headers Post', '', 'inherit', 'open', 'open', '', '28-revision-v1', '', '', '2014-02-15 11:47:09', '2014-02-15 11:47:09', '', 28, 'http://sarahtomlinson:8888/28-revision-v1/', 0, 'revision', '', 0),
(38, 1, '2014-02-15 11:47:17', '2014-02-15 11:47:17', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>', 'Multiple Paragraph Post', '', 'inherit', 'open', 'open', '', '23-revision-v1', '', '', '2014-02-15 11:47:17', '2014-02-15 11:47:17', '', 23, 'http://sarahtomlinson:8888/23-revision-v1/', 0, 'revision', '', 0),
(39, 1, '2014-02-15 11:47:17', '2014-02-15 11:47:17', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><img src="http://hivemindlabs.com/plugin-data/hive.jpg" width="100%" /><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>', 'Image Post', '', 'inherit', 'open', 'open', '', '24-revision-v1', '', '', '2014-02-15 11:47:17', '2014-02-15 11:47:17', '', 24, 'http://sarahtomlinson:8888/24-revision-v1/', 0, 'revision', '', 0),
(40, 1, '2014-02-15 11:47:17', '2014-02-15 11:47:17', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><ul><li>First Item</li><li>Second Item</li><li>Third Item</li><li>Fourth Item</li><li>Fifth Item</li></ul><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><ol><li>First Item</li><li>Second Item</li><li>Third Item</li><li>Fourth Item</li><li>Fifth Item</li></ol><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>', 'UL and OL Post', '', 'inherit', 'open', 'open', '', '25-revision-v1', '', '', '2014-02-15 11:47:17', '2014-02-15 11:47:17', '', 25, 'http://sarahtomlinson:8888/25-revision-v1/', 0, 'revision', '', 0),
(41, 1, '2014-02-15 11:47:17', '2014-02-15 11:47:17', '<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p><blockquote>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</blockquote><p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>', 'Blockquote Post', '', 'inherit', 'open', 'open', '', '26-revision-v1', '', '', '2014-02-15 11:47:17', '2014-02-15 11:47:17', '', 26, 'http://sarahtomlinson:8888/26-revision-v1/', 0, 'revision', '', 0),
(42, 1, '2014-02-15 11:47:17', '2014-02-15 11:47:17', '<p>Lorem ipsum dolor sit amet, <a href="#">consectetur adipisicing</a> elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. <a href="#">Duis aute irure</a> dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia <a href="#">deserunt</a> mollit anim id est laborum.</p>', 'Links Post', '', 'inherit', 'open', 'open', '', '27-revision-v1', '', '', '2014-02-15 11:47:17', '2014-02-15 11:47:17', '', 27, 'http://sarahtomlinson:8888/27-revision-v1/', 0, 'revision', '', 0),
(43, 1, '2014-02-15 11:48:30', '2014-02-15 11:48:30', '', 'Publication Information', '', 'publish', 'closed', 'closed', '', 'acf_publication-information', '', '', '2014-02-15 11:48:30', '2014-02-15 11:48:30', '', 0, 'http://sarahtomlinson:8888/?post_type=acf&#038;p=43', 0, 'acf', '', 0),
(44, 1, '2014-02-15 11:49:11', '2014-02-15 11:49:11', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'Multiple Paragraph Post', '', 'inherit', 'open', 'open', '', '23-revision-v1', '', '', '2014-02-15 11:49:11', '2014-02-15 11:49:11', '', 23, 'http://sarahtomlinson:8888/23-revision-v1/', 0, 'revision', '', 0),
(45, 1, '2014-02-25 12:18:22', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2014-02-25 12:18:22', '0000-00-00 00:00:00', '', 0, 'http://sarahtomlinson:8888/?p=45', 0, 'post', '', 0) ;

#
# End of data contents of table `ws_posts`
# --------------------------------------------------------



#
# Delete any existing table `ws_rg_form`
#

DROP TABLE IF EXISTS `ws_rg_form`;


#
# Table structure of table `ws_rg_form`
#

CREATE TABLE `ws_rg_form` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) NOT NULL,
  `date_created` datetime NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_trash` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `ws_rg_form`
#

#
# End of data contents of table `ws_rg_form`
# --------------------------------------------------------



#
# Delete any existing table `ws_rg_form_meta`
#

DROP TABLE IF EXISTS `ws_rg_form_meta`;


#
# Table structure of table `ws_rg_form_meta`
#

CREATE TABLE `ws_rg_form_meta` (
  `form_id` mediumint(8) unsigned NOT NULL,
  `display_meta` longtext,
  `entries_grid_meta` longtext,
  `confirmations` longtext,
  `notifications` longtext,
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `ws_rg_form_meta`
#

#
# End of data contents of table `ws_rg_form_meta`
# --------------------------------------------------------



#
# Delete any existing table `ws_rg_form_view`
#

DROP TABLE IF EXISTS `ws_rg_form_view`;


#
# Table structure of table `ws_rg_form_view`
#

CREATE TABLE `ws_rg_form_view` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` char(15) DEFAULT NULL,
  `count` mediumint(8) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `ws_rg_form_view`
#

#
# End of data contents of table `ws_rg_form_view`
# --------------------------------------------------------



#
# Delete any existing table `ws_rg_lead`
#

DROP TABLE IF EXISTS `ws_rg_lead`;


#
# Table structure of table `ws_rg_lead`
#

CREATE TABLE `ws_rg_lead` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `is_starred` tinyint(1) NOT NULL DEFAULT '0',
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `ip` varchar(39) NOT NULL,
  `source_url` varchar(200) NOT NULL DEFAULT '',
  `user_agent` varchar(250) NOT NULL DEFAULT '',
  `currency` varchar(5) DEFAULT NULL,
  `payment_status` varchar(15) DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `payment_amount` decimal(19,2) DEFAULT NULL,
  `payment_method` varchar(30) DEFAULT NULL,
  `transaction_id` varchar(50) DEFAULT NULL,
  `is_fulfilled` tinyint(1) DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `transaction_type` tinyint(1) DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `ws_rg_lead`
#

#
# End of data contents of table `ws_rg_lead`
# --------------------------------------------------------



#
# Delete any existing table `ws_rg_lead_detail`
#

DROP TABLE IF EXISTS `ws_rg_lead_detail`;


#
# Table structure of table `ws_rg_lead_detail`
#

CREATE TABLE `ws_rg_lead_detail` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `form_id` mediumint(8) unsigned NOT NULL,
  `field_number` float NOT NULL,
  `value` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `lead_id` (`lead_id`),
  KEY `lead_field_number` (`lead_id`,`field_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `ws_rg_lead_detail`
#

#
# End of data contents of table `ws_rg_lead_detail`
# --------------------------------------------------------



#
# Delete any existing table `ws_rg_lead_detail_long`
#

DROP TABLE IF EXISTS `ws_rg_lead_detail_long`;


#
# Table structure of table `ws_rg_lead_detail_long`
#

CREATE TABLE `ws_rg_lead_detail_long` (
  `lead_detail_id` bigint(20) unsigned NOT NULL,
  `value` longtext,
  PRIMARY KEY (`lead_detail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `ws_rg_lead_detail_long`
#

#
# End of data contents of table `ws_rg_lead_detail_long`
# --------------------------------------------------------



#
# Delete any existing table `ws_rg_lead_meta`
#

DROP TABLE IF EXISTS `ws_rg_lead_meta`;


#
# Table structure of table `ws_rg_lead_meta`
#

CREATE TABLE `ws_rg_lead_meta` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `lead_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`id`),
  KEY `meta_key` (`meta_key`),
  KEY `lead_id` (`lead_id`),
  KEY `form_id_meta_key` (`form_id`,`meta_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `ws_rg_lead_meta`
#

#
# End of data contents of table `ws_rg_lead_meta`
# --------------------------------------------------------



#
# Delete any existing table `ws_rg_lead_notes`
#

DROP TABLE IF EXISTS `ws_rg_lead_notes`;


#
# Table structure of table `ws_rg_lead_notes`
#

CREATE TABLE `ws_rg_lead_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `user_name` varchar(250) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `value` longtext,
  PRIMARY KEY (`id`),
  KEY `lead_id` (`lead_id`),
  KEY `lead_user_key` (`lead_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `ws_rg_lead_notes`
#

#
# End of data contents of table `ws_rg_lead_notes`
# --------------------------------------------------------



#
# Delete any existing table `ws_term_relationships`
#

DROP TABLE IF EXISTS `ws_term_relationships`;


#
# Table structure of table `ws_term_relationships`
#

CREATE TABLE `ws_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


#
# Data contents of table `ws_term_relationships`
#
INSERT INTO `ws_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(1, 2, 0),
(1, 3, 0),
(1, 4, 0),
(1, 5, 0),
(13, 6, 0),
(14, 6, 0),
(15, 6, 0),
(16, 6, 0),
(17, 6, 0),
(23, 5, 0),
(23, 7, 0),
(23, 8, 0),
(23, 9, 0),
(23, 10, 0),
(23, 11, 0),
(24, 1, 0),
(24, 2, 0),
(24, 3, 0),
(24, 4, 0),
(24, 5, 0),
(25, 1, 0),
(25, 2, 0),
(25, 3, 0),
(25, 4, 0),
(25, 5, 0),
(26, 1, 0),
(26, 2, 0),
(26, 3, 0),
(26, 4, 0),
(26, 5, 0),
(27, 1, 0),
(27, 2, 0),
(27, 3, 0),
(27, 4, 0),
(27, 5, 0),
(28, 2, 0),
(28, 3, 0),
(28, 4, 0),
(28, 5, 0) ;

#
# End of data contents of table `ws_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `ws_term_taxonomy`
#

DROP TABLE IF EXISTS `ws_term_taxonomy`;


#
# Table structure of table `ws_term_taxonomy`
#

CREATE TABLE `ws_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;


#
# Data contents of table `ws_term_taxonomy`
#
INSERT INTO `ws_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 5),
(2, 2, 'category', '', 0, 6),
(3, 3, 'category', '', 0, 6),
(4, 4, 'category', '', 0, 6),
(5, 5, 'category', '', 0, 7),
(6, 6, 'nav_menu', '', 0, 5),
(7, 7, 'post_tag', '', 0, 1),
(8, 8, 'post_tag', '', 0, 1),
(9, 9, 'post_tag', '', 0, 1),
(10, 10, 'post_tag', '', 0, 1),
(11, 11, 'post_tag', '', 0, 1) ;

#
# End of data contents of table `ws_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `ws_terms`
#

DROP TABLE IF EXISTS `ws_terms`;


#
# Table structure of table `ws_terms`
#

CREATE TABLE `ws_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;


#
# Data contents of table `ws_terms`
#
INSERT INTO `ws_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Blog', 'blog', 0),
(3, 'Fiction', 'fiction', 0),
(4, 'Essays', 'essays', 0),
(5, 'Journalism', 'journalism', 0),
(6, 'Top', 'top', 0),
(7, 'Food', 'food', 0),
(8, 'Music', 'music', 0),
(9, 'Writings', 'writings', 0),
(10, 'Etc.', 'etc', 0),
(11, 'Something Else', 'something-else', 0) ;

#
# End of data contents of table `ws_terms`
# --------------------------------------------------------



#
# Delete any existing table `ws_usermeta`
#

DROP TABLE IF EXISTS `ws_usermeta`;


#
# Table structure of table `ws_usermeta`
#

CREATE TABLE `ws_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;


#
# Data contents of table `ws_usermeta`
#
INSERT INTO `ws_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'first_name', ''),
(2, 1, 'last_name', ''),
(3, 1, 'nickname', 'epicsupreme'),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'midnight'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'ws_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(11, 1, 'ws_user_level', '10'),
(12, 1, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media,wp360_revisions,wp360_locks,aioseop_menu_211'),
(13, 1, 'show_welcome_panel', '1'),
(14, 1, 'ws_dashboard_quick_press_last_post_id', '45'),
(15, 1, 'ws_user-settings', 'libraryContent=browse'),
(16, 1, 'ws_user-settings-time', '1392161106'),
(17, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}'),
(18, 1, 'metaboxhidden_nav-menus', 'a:2:{i:0;s:8:"add-post";i:1;s:12:"add-post_tag";}') ;

#
# End of data contents of table `ws_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `ws_users`
#

DROP TABLE IF EXISTS `ws_users`;


#
# Table structure of table `ws_users`
#

CREATE TABLE `ws_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


#
# Data contents of table `ws_users`
#
INSERT INTO `ws_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'epicsupreme', '$P$BAgIXqrOmBDNHpG94/lLJEXVbvjpEU.', 'epicsupreme', 'gregattack@gmail.com', '', '2014-02-10 08:31:17', '', 0, 'epicsupreme') ;

#
# End of data contents of table `ws_users`
# --------------------------------------------------------

#
# Add constraints back in
#

